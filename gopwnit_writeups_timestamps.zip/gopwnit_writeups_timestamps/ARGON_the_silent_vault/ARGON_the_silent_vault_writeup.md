---
title: "ARGON The Silent Vault"
ctf: "Unknown"
date: 2026-10-10
category: crypto
difficulty: hard
points: 150
flag_format: "GPI{...}"
author: "bhaiya_ji"
---

# ARGON The Silent Vault

## Summary

The diagnostic channel leaks the upper 12 bits of every ECDSA nonce. This gives a Hidden Number Problem: for each signature, the nonce is known up to a 244-bit error. A lattice reduction recovers the secp256k1 private scalar. That scalar decrypts the recovery bundle; the bundle contains a common-modulus RSA instance, which yields a token used in the final Argon2id/AES-GCM vault key.

## Solution

### Step 1: Recover the ECDSA private scalar

For a signature `(r, s)` over hash `z`:

`k = s^-1(z + r*d) mod n = b + a*d mod n`.

The diagnostic record gives `k = K + delta`, where `K = leak << 244` and `0 <= delta < 2^244`. For a pivot signature 0, eliminate `d` from every other equation:

`c_i*delta_0 - delta_i = (K_i-b_i) - c_i*(K_0-b_0) (mod n)`,

where `c_i = a_i*a_0^-1 mod n`. This is a closest-vector instance. LLL plus Babai/CVP recovers `delta_0`, and then `d` is reconstructed and checked against all 96 leaked prefixes and the public key.

The recovered scalar is:

```text
0xeece93923506b3f32b4212b72a7fa5094a411becd06d2d00ce7452d4223a050c
```

### Step 2: Decrypt the recovery bundle and vault

The recovery key is HKDF-SHA256 over `d`. The decrypted JSON contains RSA ciphertexts `c1 = m^e1` and `c2 = m^e2` under the same modulus, with `gcd(e1,e2)=1`; Bezout coefficients recover `m` and the 32-byte token. Finally, Argon2id derives the vault AES-GCM key from `d` and that token.

The following complete script starts from the supplied files and prints the flag (requires `fpylll`, `cryptography`, and `argon2-cffi`):

```python
import hashlib, json, struct, random
from pathlib import Path
from fpylll import IntegerMatrix, LLL, CVP
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from argon2.low_level import hash_secret_raw, Type

P = Path("challenge")
n = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141
B = 1 << 244

pub = json.loads((P/"public.json").read_text())
sigs = [json.loads(x) for x in (P/"signatures.jsonl").read_text().splitlines()]
raw = (P/"diagnostics.bin").read_bytes()
leaks = {raw[i:i+16].hex(): struct.unpack(">H", raw[i+18:i+20])[0]
         for i in range(0, len(raw), 20)}
R = []
for q in sigs:
    z = int.from_bytes(hashlib.sha256(q["message"].encode()).digest(), "big") % n
    r, s = int(q["r"], 16), int(q["s"], 16)
    si = pow(s, -1, n)
    a, b = r*si % n, z*si % n
    K = leaks[q["id"]] * B
    R.append((a, (K-b+B//2) % n, leaks[q["id"]], s, z))

def recover(X):
    m = len(X)
    M = IntegerMatrix(m+1, m+1)
    for i, (a, *_rest) in enumerate(X):
        M[i, i] = n * (1 << 12)
        M[m, i] = a * (1 << 12)
    M[m, m] = 1
    target = tuple(t * (1 << 12) for a, t, *_ in X) + (0,)
    LLL.reduction(M, delta=0.99)
    return int(CVP.closest_vector(M, target)[-1]) % n

rng = random.Random(0x4152474F4E)
for _ in range(12):
    d = recover(rng.sample(R, 22))
    if all((p*B <= (a*d + z*pow(s, -1, n)) % n < (p+1)*B)
           for a, _t, p, s, z in R):
        break
else: raise RuntimeError("lattice recovery failed")

def gcm_open(blob, key, aad):
    return AESGCM(key).decrypt(blob[:12], blob[28:] + blob[12:28], aad)

salt = bytes.fromhex(pub["recovery_bundle"]["wrap_salt"])
key = HKDF(algorithm=hashes.SHA256(), length=32, salt=salt,
           info=b"ARGON/RECOVERY/v1").derive(d.to_bytes(32, "big"))
bundle = json.loads(gcm_open((P/"recovery.enc").read_bytes(), key,
                             b"ARGON/RECOVERY/v1"))
N = int(bundle["modulus_N"], 0)
e1, e2 = bundle["e1"], bundle["e2"]
c1, c2 = int(bundle["c1"], 0), int(bundle["c2"], 0)
def eg(a, b):
    if not b: return a, 1, 0
    g, x, y = eg(b, a % b); return g, y, x-(a//b)*y
_, u, v = eg(e1, e2)
def spow(x, e): return pow(x, e, N) if e >= 0 else pow(pow(x, -e, N), -1, N)
token = (spow(c1, u) * spow(c2, v)) % N
T = token.to_bytes(32, "big")

params = pub["vault"]["argon2_params"]
pre = hashlib.sha256(b"ARGON/FINAL/v1" + d.to_bytes(32, "big") + T).digest()
final_key = hash_secret_raw(pre, bytes.fromhex(params["final_salt"]),
    time_cost=params["time_cost"], memory_cost=params["memory_cost"],
    parallelism=params["parallelism"], hash_len=params["output_length"],
    type=Type.ID, version=params["version"])
print(gcm_open((P/"vault.enc").read_bytes(), final_key, b"ARGON/VAULT/v1").decode())
```

## Flag

```text
GPI{argon_d5e6376be1105fffc0e40e9ffcf08f52}
```
