# SHAKIRA: The Missing Soundcheck — CTF Write-up

Oct 10, 2026 · @Rank The Top 30 Countries On Their Contibutions To DigitiAtion O

## Challenge overview

| Field | Value |
| --- | --- |
| Event | gopwnit CTF 2026 |
| Challenge | SHAKIRA: The Missing Soundcheck |
| Author | bhaiya\_ji |
| Category | OSINT |
| Difficulty / points | Hard / 150 |
| Flag wrapper | GPI{...} |

> A leaked concert rehearsal photo has been attributed to the wrong venue across social media. Using offline post archives, master district plans, architectural surveys, and municipal registries, verify the true venue, identify the specific stage entrance, and reconstruct the exact soundcheck timestamp to recover the production booking.
>
> "Standard Archive Index Format: \[VENUE\]\[PORTAL\]\[DATE\]\[TIME\_UTC\]\[REF\]"

The attachment `player_package.zip` holds an offline evidence pack for a fictional city, Puerto Bahía. Most documents are in Spanish.

- `archived_posts/`: four ChirpNet social media snapshots (#7995, #8102, #8119, #8144)
- `photographs/`: the rehearsal master photo, a district panorama and a venue facade comparison
- `maps/`: district master plan and the pedestrian walkway guide
- `venue_documents/`: venue directory, two venue spec sheets, and two revisions of the Coliseo Marina Sur logistics plan
- `production_notices/`: draft tour itinerary, Operations Bulletin #04, the DSS-26 access circular, and the acoustic compliance log
- `public_records/`: time standards gazette and the October 2026 venue bookings ledger

## TL;DR

The flag is `GPI{COLMAR5_STAGEB_20261018_0140_BK9427}`.

| Field | Value | Decisive evidence |
| --- | --- | --- |
| VENUE | COLMAR5 | Arched roof and canal skybridge in the photo match only Coliseo Marina Sur |
| PORTAL | STAGEB | Sign in the photo, plus the DSS-26 circular retiring Gate 2 |
| DATE | 20261018 | Local civil date, per Gazette Art. 2 |
| TIME\_UTC | 0140 | Acoustic log start 21:40 AST + 4 h |
| REF | BK9427 | Ledger row for the official soundcheck at COLMAR5 on 2026-10-18 |

The fields are joined with underscores.

## Step 1 — Venue: COLMAR5

The photo was taken at Coliseo Marina Sur (COLMAR5), not Forum del Sol as the viral post claims.

**The false claim.** Post #8119 by @latinpop\_leaks says the soundcheck is "happening right now at FORUM DEL SOL". It is an unverified Telegram reshare, and the archive attaches a community note saying technicians dispute the venue. Fan post #8102 just reshares the same image.

**The original source.** Post #7995 by @lens\_art\_live (Lucia Mendez, El Dorado Live Touring Corp) carries the full-resolution master, which is `plate_01_rehearsal_master.png`. It was posted at 22:05 AST on 2026-10-18 with tour badge ref `TOUR-SK26-PRD`.

**Reading the photo.** Three features stand out:

1. Curved steel arch trusses sweep across the roof.
2. Through the high clerestory windows, an enclosed glass tube bridge is labelled **PASARELA NORTE \[N-3\]**.
3. Two red-and-white telecom masts (Cerro Faro) stand on a hill behind the bridge.

**Cross-checking the documents.**

| Venue | Code | Roof (venue directory) | Elevated walkway (transit guide) |
| --- | --- | --- | --- |
| Coliseo Marina Sur | COLMAR5 | Asymmetric parabolic vault, tubular steel arches | Pasarela Norte \[N-3\], 125 m enclosed glass tube over Canal Chico |
| Forum del Sol | FORUMS3 | Flat triangular space-frame, 40 m | None |
| Arena Bahía Nova | ABAHIA8 | Spherical geodesic dome, 90 m | Pasarela Este over Avenida del Sol, a road, not water |
| Palacio de las Olas | PALASO4 | Flat stepped wave slabs | None |

Section 3 of `transit_and_pedestrian_network_guide.pdf` settles it. From inside COLMAR5, through the NNW clerestory windows (335°), Pasarela Norte \[N-3\] is visible over Canal Chico with the Cerro Faro beacons behind it. The guide adds that no other venue has a view of, or a crossing over, that canal.

Post #8144 by @audio\_diego\_tech, a tour audio tech, makes the same argument: arched ribs instead of a flat lattice, and a canal skybridge with the Cerro Faro masts. That eliminates Forum del Sol.
