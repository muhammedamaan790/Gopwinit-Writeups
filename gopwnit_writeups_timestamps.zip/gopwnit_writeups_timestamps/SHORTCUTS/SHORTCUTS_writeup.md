---
title: "SHORTCUTS"
ctf: "Not specified"
date: 2026-10-10
category: reverse
difficulty: medium
points: 100
flag_format: "64-byte key (no wrapper specified)"
author: "Not specified"
---

# SHORTCUTS — treasurebox

## Summary

`treasurebox` is a stripped x86-64 PIE binary packed in a RAR archive. It requires a 64-byte input, stores it as an 8×8 byte grid, applies parity-controlled swaps, increments every byte by two, and checks the result against an embedded 8×8 target.

## Solution

### Step 1: Identify the check

Extracting the archive gives a stripped ELF. The length check rejects every key except 64 bytes. The comparison table is still plainly present in the binary as eight NUL-terminated rows:

```text
algakrwu
mvauugrv
ppkcppwa
qkpatwif
qkknaema
vqpnuvak
ptapcgnw
gfgadfcc
```

The transformation is only a permutation of bytes, followed by `byte += 2`:

1. Swap adjacent row pairs, then adjacent column pairs.
2. Swap diagonally opposite entries in every 2×2 block.
3. Scan each row left-to-right and swap adjacent bytes whose sum is even.
4. Repeat the diagonal swap. Depending on the parity of two cells, repeat the even-sum scan.
5. Depending on the parity of two other cells, run the equivalent odd-sum scan.

The scans must be undone right-to-left. The two conditional branches can be enumerated, then the candidate is run through the forward transformation to select the valid preimage.

### Step 2: Invert the permutation

This standalone script reads the embedded target directly from `treasurebox` and prints the accepted key.

```python
#!/usr/bin/env python3
from pathlib import Path

blob = Path("treasurebox").read_bytes()
needle = b"algakrwu\x00mvauugrv\x00ppkcppwa\x00qkpatwif\x00"
offset = blob.index(needle)
target = [list(blob[offset + 9 * r:offset + 9 * r + 8]) for r in range(8)]

def cp(g): return [row[:] for row in g]

def rows(g):
    for r in range(0, 8, 2): g[r], g[r + 1] = g[r + 1], g[r]

def cols(g):
    for r in range(8):
        for c in range(0, 8, 2): g[r][c], g[r][c + 1] = g[r][c + 1], g[r][c]

def diagonal(g):
    for r in range(0, 8, 2):
        for c in range(0, 8, 2): g[r][c], g[r + 1][c + 1] = g[r + 1][c + 1], g[r][c]

def scan(g, even, reverse=False):
    for r in range(8):
        for c in range(6, -1, -1) if reverse else range(7):
            if ((g[r][c] + g[r][c + 1]) & 1 == 0) == even:
                g[r][c], g[r][c + 1] = g[r][c + 1], g[r][c]

def forward(g):
    g = cp(g)
    rows(g); cols(g); diagonal(g); scan(g, True); diagonal(g)
    if not (g[1][0] & 1) or not (g[1][7] & 1): scan(g, True)
    if (g[0][1] & 1) or (g[2][7] & 1): scan(g, False)
    return [[(x + 2) & 0xff for x in row] for row in g]

# Subtract the final +2, then try both conditional branches while undoing.
encoded = [[(x - 2) & 0xff for x in row] for row in target]
for even_branch in (False, True):
    for odd_branch in (False, True):
        g = cp(encoded)
        if odd_branch: scan(g, False, reverse=True)
        if even_branch: scan(g, True, reverse=True)
        diagonal(g); scan(g, True, reverse=True); diagonal(g); cols(g); rows(g)
        if forward(g) == target:
            print(bytes(x for row in g for x in row).decode())
```

Running it prints:

```text
it_just_keeps_spinning_around_until_it_looks_nice_and_unreadable
```

### Step 3: Verify

```bash
chmod +x treasurebox
printf '%s\n' 'it_just_keeps_spinning_around_until_it_looks_nice_and_unreadable' | ./treasurebox
```

The binary responds: `The box happily accepts your key!`

## Flag

```text
it_just_keeps_spinning_around_until_it_looks_nice_and_unreadable
```
