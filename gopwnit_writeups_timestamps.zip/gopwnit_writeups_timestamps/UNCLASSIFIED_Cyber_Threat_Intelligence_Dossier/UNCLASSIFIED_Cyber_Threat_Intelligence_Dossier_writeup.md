# CTF Write-up — UNCLASSIFIED CYBER THREAT INTELLIGENCE DOSSIER

| Field | Details |
|---|---|
| **Challenge** | UNCLASSIFIED CYBER THREAT INTELLIGENCE DOSSIER |
| **Author** | bhaiya_ji |
| **Category** | OSINT |
| **Difficulty / Points** | Hard / 150 pts |
| **Final Flag** | FLAG{kaelen_voss_tromso_f9c2e0} |

## 1. The Briefing

In November 2023, cyber threat intelligence monitoring network VANGUARD-7 intercepted an emergency warrant canary trip from an underground, privacy-preserving mixnet routing project known as Heliopause Core.

For three years, the project was stewarded by a reclusive developer operating strictly under the pseudonym sternenstaub_91. Following a physical breach of their Berlin workspace by state threat group Unit 74, also known as “Leviathan,” the author wiped their primary repositories, rotated their cryptographic keys, deployed multiple deceptive transit vectors across Europe, and relocated beyond the Arctic Circle.

Before severing their connection permanently, the developer left behind:

- A forensic evidence drop
- An encrypted manifesto
- An unscrubbed Git history
- An Arctic dawn photograph

The flag format is:

    FLAG{<real_name><relocation_city><subkey_id>}

Two mirrors were provided:

- A Vite/React SPA behind a Cloudflare quick-tunnel
- A localtunnel fallback

The application exposes the following endpoints:

    GET  /api/hints
    GET  /api/search?q=...
    POST /api/submit-flag
    GET  /artifacts/heliopause_evidence_drop.zip

Their purposes are:

- GET /api/hints — progressive hints, with three tiers per stage
- GET /api/search?q=... — simulated OSINT search engine covering Wayback, passive DNS, Mastodon, transit, and CTI records
- POST /api/submit-flag — flag validator returning SUCCESS, DECOY_DETECTED, MALFORMED, INCORRECT, or RATE_LIMITED
- GET /artifacts/heliopause_evidence_drop.zip — raw forensic drop used for this write-up

The evidence drop contains:

    heliopause_evidence/
    ├── documents/
    │   ├── farewell_message.txt
    │   ├── flight_booking_inquiry_decoy.eml
    │   ├── norway_transit_bulletin.txt
    │   └── network_telemetry.csv
    ├── images/
    │   └── IMG_20231114_0812.jpg
    ├── keys/
    │   ├── compromised_key_e4b1a7.asc
    │   ├── heliopause_cold_subkeys.asc
    │   └── manifest.sha256.asc
    └── repo_snapshot/
        └── .git/

The challenge is a three-part attribution tuple, and every part is protected by decoys. The stages are solved in order:

1. Real name
2. Relocation city
3. Genuine subkey ID

## 2. Stage 1 — Real Name: Unscrubbed Git History

Classic OSINT principle: anonymization is rarely complete.

The repository snapshot's commit history shows commits made before the pseudonym was adopted:

    da6a7da  2019-04-12  Kaelen Voss <kaelen.voss@alumni.ntnu.no>
             "Initial commit of libmesh-protocol core at NTNU"
             README: "Lead Author: Kaelen Voss (kaelen.voss@alumni.ntnu.no)"

    8f722c1  2020-09-18  Kaelen Voss <kaelen.voss@alumni.ntnu.no>
             SPECIFICATION.md references "kvoss-research.io"
             "Latent Routing Over Asymmetric Mixnets" — Kaelen Voss (NTNU)

    8852138  2022-01-10  sternenstaub_91 <sternenstaub@proton.me>
             "Pseudonym migration and project anonymization"

    a02235a  2023-11-10  sternenstaub_91
             "SECURITY ADVISORY: Revoke compromised key E4B1A7;
              activate cold subkey F9C2E0"
             Note for Stage 3

    38322563  2023-11-13  sternenstaub_91
             "Emergency warrant canary tripped: archive and shutdown"

### Corroborating Evidence

The farewell dispatch lists the author as:

    sternenstaub_91 (formerly k_voss)

It signs off with:

    K.V.

The PGP master-key comment in the drop reads:

    Master: Kaelen Voss (sternenstaub_91) <sternenstaub@proton.me>

### Answer 1 — Real Name

    Kaelen Voss

This is the former academic identity associated with NTNU in Trondheim.

## 3. Stage 2 — Relocation City: EXIF and Solar/Timezone Reconciliation

The second artifact is:

    images/IMG_20231114_0812.jpg

It is an Arctic dawn harbor photograph.

### Key EXIF Fields

| EXIF tag | Value |
|---|---|
| Camera | Sony ILCE-7RM4, FE 24-70mm F2.8 GM at 24mm |
| DateTimeOriginal | 2023:11:14 08:12:44 |
| UserComment | “Timezone UTC. Harbor clock offset +01:00.” |
| ImageDescription | “Arctic twilight harbor mooring before ferry departure north.” |

### Timezone Reconciliation

The camera clock is set to UTC and records 08:12.

However, the quay clock tower visible in the photograph reads 09:12. Therefore:

    Local time = UTC + 1 hour

This immediately rules out Iceland, which uses UTC+0 in this context.

### Visual Identification

The visual cues identify Tromsø:

- A canted cantilever/suspension bridge over a sound, consistent with Tromsøbrua
- A triangular Arctic Cathedral silhouette on the far bank, consistent with Ishavskatedralen
- A mid-November solar elevation of roughly 4.2 degrees at 09:12 CET
- A latitude of approximately 69.6° N

Together, these are uniquely consistent with Tromsø.

### Supporting Corroboration

The network telemetry contains the following genuine row:

    2023-11-14 08:14 — 84.212.18.94 — Tromso (NO)
    Telenor Norge FTTH — 3.9 ms — GENUINE RESIDENCE

The other two telemetry rows are marked as decoys.

The signed manifest further states:

    Location of origin: Tromsø, Norway (69.6492 N, 18.9553 E)

### Answer 2 — Relocation City

    Tromsø

For the final flag, use the ASCII transliteration:

    tromso

## 4. Stage 3 — Genuine Subkey ID: Key-Rotation Forensics

### Timeline Reconstruction

| Date / time | Event |
|---|---|
| 2023-11-09 | Unit 74 physically raids the Berlin studio and seizes rack servers plus a backup containing the master GPG private key 0x7B92A1E4B1A7 |
| 2023-11-10 | Commit a02235a revokes E4B1A7 and activates cold-storage hardware subkey F9C2E0 |
| 2023-11-13 06:45 | Warrant canary trips: “The canary has fallen” |
| 2023-11-14 08:12 | Arctic dawn photograph is captured |
| 2023-11-14 08:14 | Genuine telemetry ping arrives from the residence; the final manifest is signed with the YubiKey subkey |

### Key Comparison

The drop contains two keys, but only one is trustworthy:

| Key | Status | Verdict |
|---|---|---|
| 0x7B92A1E4B1A7, ending in E4B1A7 | Seized and revoked — “ANY release signed with it is malicious or coerced” | DECOY |
| Subkey F9C2E0, fingerprint 4E91 B82A 03C7 91D4 E8B2 5A1F 89DC 3410 F9C2 E000 | Genuine YubiKey 5C NFC cold-storage hardware token | GENUINE |

The full genuine subkey fingerprint is:

    4E91 B82A 03C7 91D4 E8B2 5A1F 89DC 3410 F9C2 E000

### Confirmation

The file manifest.sha256.asc is clearsigned by:

    hardware subkey ID: F9C2E0
    Fingerprint ending with: F9C2 E0

Therefore, the genuine subkey ID is:

    F9C2E0

## 5. Decoys Eliminated Along the Way

| Decoy | How it was exposed |
|---|---|
| Reykjavik flight — Icelandair FI-319, burner alias “Jan Meyer” | The EML file shows that it was cancelled three hours after booking. The passenger was marked VOID and never boarded. |
| Bergen trip — Bergensbanen sleeper booking | A Bane NOR bulletin states that a rockslide between Voss and Dale suspended the entire line from 2023-11-13 to 2023-11-16. The route is ironically between Voss and Dale. |
| Berlin / Reykjavik telemetry IPs | A Mullvad commercial VPN exit and a FlokiNET seedbox; both are flagged DECOY in the CSV. |
| Master key E4B1A7 | Seized during the raid. Submitting it in the flag triggers DECOY_DETECTED. |

## 6. Assembling the Flag

The submit validator, reverse-engineered from the client-side builder, normalizes each component as follows:

| Component | Normalization | Result |
|---|---|---|
| Real name | Lowercase and replace spaces with underscores | Kaelen Voss → kaelen_voss |
| City | Lowercase | Tromsø → tromso |
| Subkey ID | Strip 0x and lowercase | F9C2E0 → f9c2e0 |

### Important Detail: ASCII Transliteration

Submitting the following flag with the ø character:

    FLAG{kaelen_voss_tromsø_f9c2e0}

returns MALFORMED from the live server. Non-ASCII characters are rejected by the validator, which expects the format FLAG{real_name_city_subkey}.

The telemetry CSV itself spells the city as:

    Tromso (NO)

Therefore, use the ASCII transliteration tromso.

## 7. Final Flag

    FLAG{kaelen_voss_tromso_f9c2e0}

## 8. Summary

| Component | Answer | Source of Truth |
|---|---|---|
| Real name | kaelen_voss | Unscrubbed Git commits from 2019–2020, kvoss-research.io, farewell dispatch stating “formerly k_voss,” and the PGP master-key comment |
| Relocation city | tromso | EXIF UTC-versus-quay-clock reconciliation, UTC+1 timezone, Tromsøbrua and Arctic Cathedral visual cues, genuine FTTH telemetry, and manifest coordinates |
| Subkey ID | f9c2e0 | Commit a02235a key-rotation advisory; genuine YubiKey cold subkey signed the final manifest |

**Final Flag:**

    FLAG{kaelen_voss_tromso_f9c2e0}
