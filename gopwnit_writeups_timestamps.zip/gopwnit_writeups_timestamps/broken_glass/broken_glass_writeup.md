# broken glass: writeup

**Category:** Forensics · **Difficulty:** Easy · **Points:** 50 · **Author:** GOPWNIT

**Flag:** `GPI{f1x_th3_h34d3r_f1x_th3_byt3_r34d_th3_p1x3ls_71d8}`

## Challenge

> The archive was on a card that had been snapped in half. A lab recovered most of it. Nothing opens it.

Attachment: `dist.zip` → `evidence.zip` (157,175 bytes)

## 1. The truncated ZIP

`evidence.zip` has **no End of Central Directory record**: the archive is cut off just after the central directory starts. That's why "nothing opens it". The **local file headers** are still intact, though, so each entry can be read straight from the bytes:

```python
import struct, zlib
d = open('evidence.zip', 'rb').read()
i = 0
while (i := d.find(b'PK\x03\x04', i)) != -1:
    ver, flag, meth, mt, md, crc, cs, us, nl, el = struct.unpack('<HHHHHIIIHH', d[i+4:i+30])
    name = d[i+30:i+30+nl].decode(); s = i + 30 + nl + el
    # flag 0x08 = sizes are stored in a data descriptor after the data, so cs = 0 here
    data = d[s:s+cs] if meth == 0 else zlib.decompressobj(-15).decompress(d[s:])
    open(name.split('/')[-1], 'wb').write(data)
    i += 4
```

| Offset | Entry | Method | Result |
|---|---|---|---|
| 0 | `evidence/README.txt` | stored | text |
| 117 | `evidence/thumb.png` | deflate (sizes in data descriptor) | a valid PNG, 1096×78 |
| 76152 | `evidence/photo.png` | deflate (sizes in data descriptor) | **broken PNG** |

Deflate streams mark their own end, so raw inflate (`wbits=-15`) works without knowing the compressed size.

## 2. The decoys

| Source | Flag |
|---|---|
| `README.txt` (also visible with `strings`) | `GPI{str1ngs_0n_4_z1p_n3v3r_g3ts_0ld_20a9}` |
| `thumb.png`, which opens without repair | `GPI{th3_f1rst_png_th4t_0p3ns_1s_th3_4nsw3r_e6c3}` |
| `photo.png` `tEXt Comment` (Base64) | `GPI{t3xt_chunks_4r3_fr33_r34l_3st4t3_15d7}` |

## 3. Repairing `photo.png`

```
00000000: 0000 0000 0000 0000 0000 000d 4948 4452  ............IHDR
00000010: 0000 0000 0000 0000 0800 0000 0018 83c0  ................
          ^ width ^ ^ height^ depth=8, colour=0 (grey), CRC=1883c02e
```

Three things are damaged:

1. **The PNG signature is zeroed.** Restore `89 50 4E 47 0D 0A 1A 0A`.
2. **Width and height are zeroed in IHDR**, but the **IHDR CRC was left alone**. Brute-force the `(w, h)` pair whose CRC matches:

   ```python
   rest = d[24:29]                       # depth, colour, comp, filter, interlace
   crc  = int.from_bytes(d[29:33], 'big')
   for w in range(1, 4000):
       for h in range(1, 4000):
           if zlib.crc32(b'IHDR' + struct.pack('>II', w, h) + rest) == crc:
               print(w, h)               # 1206 78
   ```

   Cross-check: the decompressed image data is **94,146 bytes** = 78 × (1206 + 1). ✔

3. **The zlib Adler-32 checksum is wrong** (stored `36aa5cfc`, computed `a6745c7a`), so strict decoders refuse the file even after the header is fixed. Get around it by raw-inflating the IDAT data (skip the 2-byte zlib header, `wbits=-15`) and decoding the rows yourself. Every row uses filter 0, so the pixel bytes can be used as-is:

   ```python
   z = zlib.decompressobj(-15); raw = z.decompress(idat[2:])
   W, H = 1206, 78
   img = np.frombuffer(raw, np.uint8).reshape(H, W + 1)[:, 1:]   # remove filter bytes
   Image.fromarray(img).save('photo_render.png')
   ```

   (Or replace the last 4 bytes of the final IDAT with the computed Adler-32 and recompute that chunk's CRC. Then any viewer opens it.)

## 4. Read the pixels

The repaired `photo.png` shows:

```
GPI{f1x_th3_h34d3r_f1x_th3_byt3_r34d_th3_p1x3ls_71d8}
```

The flag text itself describes the steps: fix the header (signature and dimensions), fix the byte (the checksum), read the pixels.

## Flag

```
GPI{f1x_th3_h34d3r_f1x_th3_byt3_r34d_th3_p1x3ls_71d8}
```
