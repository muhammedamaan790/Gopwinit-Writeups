---
title: "Candle Wright"
ctf: "Unspecified"
date: 2026-10-10
category: crypto
difficulty: easy
points: 50
flag_format: "GPI{...}"
author: "gopwnit (challenge author)"
---

# Candle Wright

## Summary

`intercept.txt` is Base64-wrapped ciphertext.  Its repeating patterns indicate
a repeating-key XOR cipher; breaking it reveals an internal memo that describes
how to derive a dispatch key and decrypt the actual flag.  The operator code in
the memo is a deliberate decoy.

## Solution

### Step 1: Break the repeating-key XOR

After excluding the comment lines and Base64-decoding, the payload is 1,491
bytes.  Repeated ciphertext runs occur at offsets separated by multiples of
nine, identifying a nine-byte XOR key.  Solving each key column as a
single-byte XOR gives `c012979878120b52bd` and decrypts the memo.

The memo says to retain only letters inside the operator-code braces, shift
each letter forward by its 1-based position, and lowercase the result.  It then
defines the sealed line as XOR with a repeated SHA-256 digest of that derived
key.

The following script performs the full recovery from the supplied handout:

```python
#!/usr/bin/env python3
import base64
import hashlib
import re


def english_score(data: bytes) -> int:
    """Lightweight score for a single-byte XOR column."""
    common = b" etaoinshrdluETAOINSHRDLU"
    return sum(
        3 if byte in common else 1 if 32 <= byte < 127 or byte in b"\n\r\t" else -20
        for byte in data
    )


# Decode the memo, skipping its descriptive comment lines.
encoded = "".join(
    line.strip()
    for line in open("handout/intercept.txt", encoding="ascii")
    if line and not line.startswith("#")
)
ciphertext = base64.b64decode(encoded)

# Repeated runs are aligned modulo 9, so solve nine independent XOR columns.
key = bytes(
    max(range(256), key=lambda candidate: english_score(
        bytes(value ^ candidate for value in ciphertext[offset::9])
    ))
    for offset in range(9)
)
memo = bytes(value ^ key[index % len(key)] for index, value in enumerate(ciphertext))
print(memo.decode())

# Parse and transform the decoy operator code exactly as instructed by the memo.
operator = re.search(rb"operator code for this week is GPI\{([^}]+)\}", memo).group(1)
letters = bytes(char for char in operator.lower() if 97 <= char <= 122)
dispatch_key = bytes((char - 97 + position) % 26 + 97
                     for position, char in enumerate(letters, start=1))

# Extract and open the final sealed line using the repeated SHA-256 digest.
sealed_b64 = re.search(rb"sealed line \(base64\):[ \t]*\n([A-Za-z0-9+/=]+)", memo).group(1)
sealed = base64.b64decode(sealed_b64)
digest = hashlib.sha256(dispatch_key).digest()
opened = bytes(byte ^ digest[index % len(digest)] for index, byte in enumerate(sealed))
flag = re.search(rb"GPI\{[^}]+\}", opened).group().decode()
print(flag)
```

Running it prints the memo and then the flag.  It was also accepted by the
provided verifier:

```text
$ python3 handout/check.py 'GPI{r34d_th3_m3m0_n0t_just_th3_br4c3s}'
accepted -- that is the dispatch flag.
```

## Flag

```text
GPI{r34d_th3_m3m0_n0t_just_th3_br4c3s}
```
