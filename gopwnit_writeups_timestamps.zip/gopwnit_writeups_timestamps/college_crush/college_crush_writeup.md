---
title: "college_crush"
ctf: "Unspecified"
date: 2026-10-10
category: reverse
difficulty: medium
points: 100
flag_format: "zplus{...}"
author: "CTF player"
---

# college_crush

## Summary

The executable is a Windows x64 flag checker with a small custom instruction format. Its `.zplus` section decodes to a sequence of bytewise transformations; reversing those transformations over the embedded comparison target recovers the flag.

## Solution

### Step 1: Decode the instruction stream

`college_crush.exe` has a `.zplus` section containing 35 bytes:

```
7a 11 22 70 11 22 7a 11 22 70 11 22 7a 11 22 6c
11 22 7a 11 22 70 11 22 7a 11 22 6c 11 22 75 11 33 73 11
```

The static lookup table maps `z`, `p`, `l`, `u`, and `s` to `xor`, `shl`, `shr`, `comp`, and `ret`. The decoded program is:

```
xor[value][key]
shl[value][key]
xor[value][key]
shl[value][key]
xor[value][key]
shr[value][key]
xor[value][key]
shl[value][key]
xor[value][key]
shr[value][key]
comp[value][target]
ret[value]
```

The interpreter implements these as `xor 0x5a`, `ror 6`, and `ror 2`, respectively. The embedded target at `main+0x148` is:

```
80 a8 d8 bc a4 84 4c 14 34 ec 00 14 38 d4 d4 14 58 ec 80 8c 9c
```

### Step 2: Reverse the transformations

Applying the inverse operations in reverse order (`xor` is its own inverse and `ror n` becomes `rol n`) gives a complete reproducer:

```python
target = bytes.fromhex("80a8d8bca4844c1434ec001438d4d41458ec808c9c")
ops = [
    ("xor", 0x5A), ("ror", 6), ("xor", 0x5A), ("ror", 6),
    ("xor", 0x5A), ("ror", 2), ("xor", 0x5A), ("ror", 6),
    ("xor", 0x5A), ("ror", 2),
]

def rol(byte, count):
    return ((byte << count) | (byte >> (8 - count))) & 0xFF

value = bytearray(target)
for operation, argument in reversed(ops):
    for index, byte in enumerate(value):
        value[index] = byte ^ argument if operation == "xor" else rol(byte, argument)

print(value.decode())
```

Output:

```
zplus{I_WaZ_Too_Lazy}
```

## Flag

```
zplus{I_WaZ_Too_Lazy}
```
