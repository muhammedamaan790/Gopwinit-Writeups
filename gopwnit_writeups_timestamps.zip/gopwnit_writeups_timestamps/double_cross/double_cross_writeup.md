# double cross: writeup

**Category:** Cryptography · **Difficulty:** Easy · **Points:** 50 · **Author:** GOPWNIT

**Flag:** `GPI{tw0_shuffl3s_unddone_1n_r3v3rs3_0e85}`

## Challenge

> A message run through a columnar transposition twice, under two different keywords. Both keywords were signalled: one in semaphore, one in Morse.

Attachment: `dist.zip` contains:
- `message.txt`: the ciphertext
- `key1.png`: a picture of semaphore figures
- `key2.gif`: a blinking-light animation
- `unlock.py`: an answer checker that asks for "the phrase once both transpositions are undone"

Ciphertext (51 characters):

```
SAAVCWTUNSSRANOTEIEOESEFTONRROETRTDHITHIOIONAPTOIIPS
```

## Key 1: semaphore (`key1.png`)

The image shows seven stick figures holding two flags each. Reading each pair of arm positions as seen by the viewer:

| # | Arms | Letter |
|---|---|---|
| 1 | left + low-left | H |
| 2 | low-left + down | A |
| 3 | left + right | R |
| 4 | left + down | B |
| 5 | high-left + left | O |
| 6 | high-left + high-right | U |
| 7 | left + right | R |

**Key 1 = `HARBOUR`**

## Key 2: Morse code from a lamp (`key2.gif`)

The GIF has 31 frames that alternate between a dark lamp and a lit lamp. Each frame's display time is the signal:

```python
from PIL import Image, ImageSequence
print([f.info['duration'] for f in ImageSequence.Iterator(Image.open('key2.gif'))])
# [600, 200, 200, 600, 200, 200, 200, 200, 600, 200, 200, 600, 600, 600, 200, 200,
#  600, 600, 600, 200, 600, 200, 200, 600, 200, 200, 600, 600, 200, 200, 1400]
```

- Lit 200 ms = dot, lit 600 ms = dash
- Dark 200 ms = gap within a letter, dark 600 ms = gap between letters, the final 1400 ms = end

```
.-..  .-  -.  -  .  .-.  -.
 L    A   N   T  E   R   N
```

**Key 2 = `LANTERN`**

## Undoing the double columnar transposition

The encryption used `HARBOUR` first, then `LANTERN`, so decryption goes in reverse: undo `LANTERN`, then undo `HARBOUR`. The grids are irregular: the last row is short, so the leftmost `len % keylen` columns get one extra letter. Repeated letters in a key are numbered left to right.

```python
ct = open('message.txt').read().strip()

def order(k):
    return sorted(range(len(k)), key=lambda i: (k[i], i))

def dec(c, k):
    n, L = len(k), len(c)
    rows = -(-L // n); full = L % n or n
    lens = [rows if i < full else rows - 1 for i in range(n)]
    cols, p = [None] * n, 0
    for i in order(k):
        cols[i] = c[p:p + lens[i]]; p += lens[i]
    return ''.join(cols[i][r] for r in range(rows) for i in range(n) if r < len(cols[i]))

print(dec(dec(ct, 'LANTERN'), 'HARBOUR'))
# ATRANSPOSITIONOFATRANSPOSITIONHIDESTHEROUTETWICEOVER
```

Undoing them in the other order (`HARBOUR` first) gives nonsense, which confirms the order.

Plaintext: **A TRANSPOSITION OF A TRANSPOSITION HIDES THE ROUTE TWICE OVER**

## Unlock

```bash
python3 unlock.py "ATRANSPOSITIONOFATRANSPOSITIONHIDESTHEROUTETWICEOVER"
# GPI{tw0_shuffl3s_unddone_1n_r3v3rs3_0e85}
```

## Flag

```
GPI{tw0_shuffl3s_unddone_1n_r3v3rs3_0e85}
```

(It really is spelled `unddone` with two d's. Submit it exactly as shown.)
