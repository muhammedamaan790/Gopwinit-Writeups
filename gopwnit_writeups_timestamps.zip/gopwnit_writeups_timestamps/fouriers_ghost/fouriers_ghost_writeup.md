# Fouriers-ghost: writeup

**Category:** Steganography · **Difficulty:** Easy · **Points:** 50 · **Author:** GOPWNIT

**Flag:** `GPI{l0w_byt3s_dr34m_1n_fr3qu3ncy_sp4c3_2c96}`

## Challenge

> You are only seeing half of every pixel. The other half is not a picture of anything. It is a picture of everything, all at once.

Attachment: `dist.zip` → `ghost.png` (1024×1024, **16-bit grayscale**)

## Hints in the description

- **"Half of every pixel"**: each 16-bit pixel has a high byte and a low byte. Normal viewers show only the high byte.
- **"A picture of everything, all at once"**: a Fourier transform. Every point in frequency space depends on every pixel of the image.

## Decoy: the PNG comment

```python
Image.open('ghost.png').info
# {'Comment': 'R1BJe3MxeHQzM25fYjF0c18wZl9uMHRoMW5nX24zd19lMmExfQ=='}
```

Base64-decoded: `GPI{s1xt33n_b1ts_0f_n0th1ng_n3w_e2a1}` is a decoy ("sixteen bits of nothing new").

## 1. Split the bytes and take the FFT of the low byte

```python
import numpy as np
from PIL import Image

a  = np.array(Image.open('ghost.png')).astype(np.uint16)
hi = (a >> 8).astype(np.uint8)    # the visible image: smooth blobs
lo = (a & 255).astype(np.uint8)   # looks like pure noise

F = np.fft.fftshift(np.fft.fft2(lo.astype(float)))
mag = np.log1p(np.abs(F))
Image.fromarray((255 * (mag - mag.min()) / np.ptp(mag)).astype(np.uint8)).save('lo_fft.png')
```

The low byte looks like noise, but its Fourier magnitude shows text (once normally and once rotated 180°, because the FFT of a real image is symmetric):

```
HIGH BYTE, bit 0
columns right to left,
each column bottom-up
u16be L | nonce[12] | AES-256-GCM
key = SHA256(PASS)
PASS = MERIDIAN-204-LOWTIDE
```

## 2. Extract the hidden bits from the high byte

- Take bit 0 (the least significant bit) of the **high** byte of each pixel
- Read **columns from right to left**, and each column **from bottom to top**
- Pack into bytes, most significant bit first

```python
bits = ((a >> 8) & 1)[::-1, ::-1].T.flatten()
data = np.packbits(bits).tobytes()
```

## 3. Parse and decrypt

Layout: `u16be L | nonce[12] | AES-256-GCM ciphertext+tag`

**Gotcha:** `L = 72` covers the **nonce and the ciphertext together** (12 + 60), not just the ciphertext. Taking 72 bytes of ciphertext fails the GCM tag check. The correct ciphertext length is `L − 12 = 60` (44 bytes of plaintext + 16-byte tag).

```python
import hashlib
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

L     = int.from_bytes(data[:2], 'big')   # 72
nonce = data[2:14]
ct    = data[14:2 + L]                    # 60 bytes
key   = hashlib.sha256(b'MERIDIAN-204-LOWTIDE').digest()

print(AESGCM(key).decrypt(nonce, ct, None))
# b'GPI{l0w_byt3s_dr34m_1n_fr3qu3ncy_sp4c3_2c96}'
```

AES-GCM checks a tag, so a successful decryption confirms the flag.

## Flag

```
GPI{l0w_byt3s_dr34m_1n_fr3qu3ncy_sp4c3_2c96}
```
