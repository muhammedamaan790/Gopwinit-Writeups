---
title: "GOOD_TO_SEE_YOU"
ctf: "Unspecified"
date: 2026-10-10
category: forensics
difficulty: medium
points: 100
flag_format: "GPI{...}"
author: "Unknown"
---

# GOOD_TO_SEE_YOU

## Summary

The ext4 image contained a deleted encrypted ZIP archive and a deleted Bash history file. ext4 retained both inodes, so Sleuth Kit could recover the command that created the archive (including its password) and the archive itself.

## Solution

### Step 1: Identify recoverable deleted files

`fls` recursively lists allocated and deleted directory entries. The asterisk marks deleted files:

```bash
$ fls -r -p disk.img
d/d 11:  lost+found
r/r 12:    readme.txt
r/r 13:    decoy.txt
r/r * 14:  .bash_history
r/r * 15:  old_config2.txt
r/r * 16:  deleted_vault.zip
```

The intended archive is inode `16`, while the deleted history is inode `14`. Recovering the history with `icat` exposes the original archive command:

```text
zip -e -P "VaultKey_9ae865d44a" deleted_vault.zip flag.txt
```

### Step 2: Recover and decrypt the archive

The following complete script starts from `disk.img`, locates the deleted history/archive entries, extracts the password from the history, and decrypts `flag.txt`.

```python
#!/usr/bin/env python3
import re
import subprocess
import sys
import zipfile

image = sys.argv[1] if len(sys.argv) > 1 else "disk.img"
listing = subprocess.check_output(["fls", "-r", "-p", image], text=True)

def deleted_inode(name):
    match = re.search(rf"^r/r \* (\d+):\s+{re.escape(name)}$", listing, re.M)
    if not match:
        raise RuntimeError(f"Deleted {name} not found")
    return match.group(1)

def icat(inode):
    return subprocess.check_output(["icat", image, inode])

history = icat(deleted_inode(".bash_history")).decode(errors="replace")
password = re.search(r'zip -e -P "([^"]+)" deleted_vault\.zip', history).group(1)
archive = icat(deleted_inode("deleted_vault.zip"))

with open("recovered_vault.zip", "wb") as f:
    f.write(archive)
with zipfile.ZipFile("recovered_vault.zip") as zf:
    print(zf.read("flag.txt", pwd=password.encode()).decode().strip())
```

```text
$ python3 solve.py disk.img
Here is the real flag. Note: don't let anyone see this.
GPI{z1p_c4rv1ng_1s_fun_9ae865d44a6f}
```

## Flag

```
GPI{z1p_c4rv1ng_1s_fun_9ae865d44a6f}
```
