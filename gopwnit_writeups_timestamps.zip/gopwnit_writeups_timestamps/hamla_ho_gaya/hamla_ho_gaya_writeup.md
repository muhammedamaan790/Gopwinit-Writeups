---
title: "HAMLA_HO_GAYA"
ctf: "Not provided"
date: 2026-10-10
category: forensics
difficulty: medium
points: 100
flag_format: "FLAG{...}"
author: "bhaiya_ji"
---

# HAMLA_HO_GAYA

## Summary

The flag is split across `logs.txt`, `traffic.pcap`, and `memory.mem`. The obvious standalone `FLAG{...}` strings are decoys; the PCAP's token decrypts the actual suffix stored immediately before a memory marker.

## Solution

### Step 1: Decode the anomalous log timestamps

The 10 `WARN` records are distinct from the 500 noisy `INFO` records. Their millisecond values are decimal ASCII:

```text
070 076 065 071 123 084 049 109 051 095
 F   L   A   G   {   T   1   m   3   _
```

This yields the prefix `FLAG{T1m3_`.

### Step 2: Decode the PCAP fragment and decrypt the memory suffix

The PCAP contains four requests with Base64 `session_id` cookie values. Decoding and joining them produces `fl0w5_1nt0_`. The same requests carry the repeated `auth_token=42`.

The raw memory image has an injected `[PAYLOAD_END]=` marker at `0x60002a`. XOR the preceding 42 bytes with the PCAP's numeric token (`0x2a`). The printable tail of that result is `m3m0ry_v01d}`. The standalone flag at `0x500000` and the HTML-comment flag in the HTTP response are decoys.

The following standard-library solver extracts every fragment from the supplied files and prints the reconstructed flag:

```python
import base64, re
from pathlib import Path

e = Path("evidence")
logs = (e / "logs.txt").read_text(encoding="ascii")
prefix = "".join(chr(int(x)) for x in re.findall(r"\.(\d{3})\] \[WARN\]", logs))
pcap = (e / "traffic.pcap").read_bytes()
middle = b"".join(base64.b64decode(x) for x in re.findall(rb"session_id=([A-Za-z0-9+/=]+)", pcap)).decode()
key = int(set(re.findall(rb"auth_token=(\d+)", pcap)).pop())
memory = (e / "memory.mem").read_bytes()
end = memory.index(b"[PAYLOAD_END]=")
decoded = bytes(x ^ key for x in memory[end - key:end])
suffix = re.search(rb"([A-Za-z0-9_]+\})$", decoded).group(1).decode()
print(prefix + middle + suffix)
```

Output:

```text
FLAG{T1m3_fl0w5_1nt0_m3m0ry_v01d}
```

## Flag

```text
FLAG{T1m3_fl0w5_1nt0_m3m0ry_v01d}
```
