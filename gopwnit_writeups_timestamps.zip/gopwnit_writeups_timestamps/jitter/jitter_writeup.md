# Jitter: writeup

**Category:** Forensics · **Difficulty:** Medium · **Points:** 100 · **Author:** GOPWNIT

**Flag:** `GPI{th3_p4yl04d_w4s_n01s3_th3_g4ps_w3r3_th3_m3ss4g3_d5b0}`

## Challenge

> A host on the factory network pings one outside address, all day, every day. Monitoring flagged it as harmless. Twenty minutes of it are in this capture.

Attachment: `dist.zip` → `ping.pcap` (4400 frames)

## 1. Overview

```bash
tshark -r ping.pcap -q -z conv,ip
```

| Host | Peer | Traffic |
|---|---|---|
| 10.20.0.57 | 192.0.2.9 | 1300 ICMP echo request/reply pairs, about 1 per second |
| 10.20.0.99 | 192.0.2.50 | 500 ICMP echo pairs, irregular timing |
| both | 10.20.0.1 | 800 DNS queries for random `www.<word><word>.example` names (noise) |

Host `.99` (constant payload, evenly spread random gaps) and the DNS lookups are **cover traffic**. The interesting host is **10.20.0.57**.

## 2. Decoys in host .57's pings

```bash
tshark -r ping.pcap -Y "icmp.type==8 && ip.src==10.20.0.57" \
  -T fields -e frame.time_epoch -e ip.ttl -e ip.id -e icmp.seq -e data.data > a.tsv
```

| Channel | How | Result |
|---|---|---|
| ICMP payload byte 8 | one byte per packet | `GPI{1cmp_d4t4_f13ld_3xf1l_cl4ss1c_7e2b}`, a decoy |
| IP TTL | 64 = `0`, 65 = `1`, 8 bits per byte | `GPI{ttl_b1ts_4r3_th3_cl3v3r_0n3_r1ght_d913}`, a decoy |

## 3. The timing channel ("jitter")

The gaps between host `.57`'s echo requests fall into two tight groups:

| Gap | Count | Bit |
|---|---|---|
| about 0.98–1.02 s | ~970 | `0` |
| about 1.22–1.27 s | ~330 | `1` |

```python
import numpy as np
t = [float(l.split('\t')[0]) for l in open('a.tsv')]
bits = ''.join('1' if d > 1.12 else '0' for d in np.diff(t))
print(bytes(int(bits[i:i+8], 2) for i in range(0, len(bits) - 7, 8)))
```

```
\xaa U  \  IP-ID low byte of each request: u16be L, nonce[12], AES-256-GCM. key=SHA256('TIDEMARK-0619')
```

(`AA 55` is a sync preamble. The text is the next-stage instructions.)

## 4. The IP ID channel

Take the **low byte of the IPv4 Identification field** of each echo request from `.57`:

```python
import hashlib
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

ids   = [int(l.split('\t')[2], 16) for l in open('a.tsv')]
d     = bytes(v & 0xff for v in ids)
L     = int.from_bytes(d[:2], 'big')        # 85 = 12-byte nonce + 73-byte ciphertext+tag
nonce = d[2:14]
ct    = d[14:2 + L]
key   = hashlib.sha256(b'TIDEMARK-0619').digest()
print(AESGCM(key).decrypt(nonce, ct, None))
# b'GPI{th3_p4yl04d_w4s_n01s3_th3_g4ps_w3r3_th3_m3ss4g3_d5b0}'
```

As in the other GOPWNIT challenges, `L` counts the nonce together with the ciphertext. The GCM tag check passes, so the flag is confirmed.

## Flag

```
GPI{th3_p4yl04d_w4s_n01s3_th3_g4ps_w3r3_th3_m3ss4g3_d5b0}
```

**Takeaway:** pings that look harmless can hide data in the payload, the TTL, the IP ID and the timing between packets. Here the timing carried the instructions and the IP ID carried the encrypted flag. The two obvious channels were bait.
