# leaky crt: writeup

**Category:** Cryptography · **Difficulty:** Easy · **Points:** 50 · **Author:** GOPWNIT

**Flag:** `GPI{0n3_l34k3d_crt_3xp0n3nt_1s_3n0ugh_c05e}`

## Challenge

> A debug build of a signing library wrote one of its Chinese-Remainder private values, `dp`, into a log before anyone noticed. The public key and an encrypted flag are attached.

Attachment: `dist.zip` contains:
- `key.txt`: `n` (1024-bit), `e = 65537`, `dp`
- `cipher.txt`: `c`

## Background

To speed up decryption and signing, RSA implementations use the Chinese Remainder Theorem (CRT) and store:

- `dp = d mod (p − 1)`
- `dq = d mod (q − 1)`
- `qinv = q⁻¹ mod p`

Leaking **just `dp`** is enough to factor `n`.

## The attack

Since `e·d ≡ 1 (mod φ(n))`, it follows that `e·dp ≡ 1 (mod p − 1)`. So `e·dp = 1 + k(p − 1)` for some integer `k`.

By Fermat's little theorem, for any `a` not divisible by `p`:

```
a^(e·dp) = a · (a^(p−1))^k ≡ a  (mod p)
```

So `p` divides `a^(e·dp) − a`. Unless `q` happens to divide it too (very unlikely), we get:

```
p = gcd(a^(e·dp) − a  mod n,  n)
```

There's another way that gives the same `p`. Since `dp < p − 1`, we know `k < e`, so you can loop over `k = 1 … 65536` and test `p = (e·dp − 1)/k + 1`. The gcd method is a single step.

## Solver

```python
from math import gcd

n  = 88272710306021897053593963316952856547434338862724788239766153413862868158875953750748910833191163685033439826316235186789793424168932945318691573928208479387396821727660116280529019195904853245836934662270240271082956979027507951391802969522976512905875303511421058346840993947679172428242605097392884123037
e  = 65537
dp = 3216269073224984940153500850580485257266014347264225337400837570858204398215393223589875242469597470511428315970897676303205569856012127638051050397887061
c  = 8435009986724574036937890136525780682550919844574409201151050667870994806123093631641155055863502327401585230682262249844641560735809524773312916254405551920773198655528173065253536750380391824063933128801304973524554745918987200634231202939560821645001409224844142639568470371402604016687626257364827232625

p = gcd(pow(2, e * dp, n) - 2, n)
q = n // p
assert p * q == n

d = pow(e, -1, (p - 1) * (q - 1))
m = pow(c, d, n)
print(m.to_bytes((m.bit_length() + 7) // 8, 'big'))
# b'GPI{0n3_l34k3d_crt_3xp0n3nt_1s_3n0ugh_c05e}'
```

## Flag

```
GPI{0n3_l34k3d_crt_3xp0n3nt_1s_3n0ugh_c05e}
```

**Takeaway:** each CRT parameter (`dp`, `dq`) is as sensitive as `d` itself. Leaking just one of them gives up the whole private key.
