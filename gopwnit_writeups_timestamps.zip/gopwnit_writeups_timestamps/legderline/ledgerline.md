# ledgerline — CTF Writeup

## Challenge Information

- Challenge: Ledgerline
- Category: Web / cryptography
- Difficulty: Medium
- Flag format: `CTF{...}`

## Challenge Description

## Initial Analysis

The API publishes all ten signed entries, the P-256 public key, and the exact
canonical encoding.  The restore endpoint accepts a base64 blob and `(r,s)`.
Several unrelated entries have identical `r` values, which proves ECDSA nonce
reuse.

## Solution

For two signatures with the same `r`, calculate

```text
k = (z1 - z2) / (s1 - s2) mod n
d = (s1*k - z1) / r mod n
```

where `z` is SHA-256 of the canonical entry encoding and `n` is the P-256
order.  Using entries 2 and 4 gives:

```text
d = a46756e24436a3e087bf678e9bfbcb4b9930b06dd81e6746562722831bfe7181
```

`d*G` equals the published point `(x=75dbdc..., y=c3cebf...)`.  I then signed
the snapshot encoding `ledgerline.snapshot.v2 || 0x1f || varint(len(blob)) ||
blob`.  The restore handler unpickles the blob, so the signed pickle invoked
`cat /flag.txt`; its returned representation contained the flag.

## Important Commands

```bash

```

## Scripts Used

## Key Evidence

## Flag Derivation

## Verified Flag

```text
CTF{d3t3rm1n1st1c_n0nc3_b0und_t0_th3_wr0ng_th1ng}
```

## Lessons / Observations
