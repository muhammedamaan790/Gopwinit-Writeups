# Lost and found: writeup

**Category:** Miscellaneous · **Difficulty:** Easy · **Points:** 50 · **Author:** GOPWNIT

**Flag (most likely):** `GPI{d4ngl1ng_c0mm1ts_n3v3r_r34lly_l34v3_7a3e}`

## Challenge

> The harbour office kept its tide tables in a repository. Someone tidied it before handing it over. They were thorough, by their own account.

Attachment: `dist.zip` contains:
- `harbour.git.tar`: a bare git repository
- `unlock.py`: an answer checker that asks for "the phrase"

## unlock.py

The checker normalises your answer (lowercase, keeps only `a-z0-9`) and runs it through scrypt (n=2^17, so each try is slow). It then checks the result against **two** encrypted boxes, each protected by an HMAC tag. Either box decrypts if its phrase is right.

So there are two valid phrases, which almost certainly means one decoy and one real answer. Brute-forcing isn't practical; the phrases have to be found in the repo.

## Repo overview

```bash
tar xf harbour.git.tar
cd harbour.git
git log --oneline --all
```

```
65a00d8 typo
bcee094 update tides
729150f remove secret, oops
b507907 add the key for the harbour office
87c3d0c add berth notes
68122fa initial import
```

Leftovers worth noting:
- `logs/HEAD`: the reflog was **not** cleared
- `objects/pack/tmp_pack_568fed`: a half-written pack file from an interrupted repack or gc

## Layer 1: the obvious secret (decoy)

```bash
git show b507907
```

`secret.txt` contains:

```
R1BJezBsZF8zbmMwZDFuZ3NfZDEzX2g0cmRfbDAwa180dF90aDNfbDRzdF9ieXQzc183NGY5fQ==
```

Base64-decoded: `GPI{0ld_3nc0d1ngs_d13_h4rd_l00k_4t_th3_l4st_byt3s_74f9}`

This sits in the visible history and only needs Base64 decoding. It's a decoy.

## Layer 2: the deleted `scratch` branch (in the reflog)

`logs/HEAD` records 12 `wip` commits on a branch called `scratch`, starting from `87c3d0c`. The branch was later deleted (`checkout: moving from scratch to main`). The commit objects are still in the main pack.

Each commit replaces one file, `part`, with a few bytes. The first one starts with `1f8b08`, the gzip header. Joining them in order:

```bash
for c in $(git rev-list --reverse 87c3d0c..2076cd569c8ce3fc4f5869ef437e7d6f3bf70e9c); do
  git cat-file -p $c:part
done | gunzip
# phrase: CHECK THE REFLOG
```

```bash
python3 unlock.py "CHECK THE REFLOG"
# GPI{th3_l0gs_r3m3mb3r_bl1nd_sp0ts_3v3rywh3r3_f3fa}
```

The phrase points at the reflog, where the solver already is. That makes it the bait for someone who stops after `git reflog`.

## Layer 3: dangling commits in the leftover pack (real)

`tmp_pack_568fed` declares 103 objects but is cut off, so `git index-pack` fails with `fatal: early EOF`. Parsing it by hand still recovers the first 72 complete objects. Every object is stored whole (no deltas), so each one decompresses with zlib on its own:

1. Read the 12-byte header (`PACK`, version, object count).
2. For each object, read the type and size header, decompress the zlib stream, and hash `"<type> <len>\0" + body` with SHA-1 to get its ID.
3. Stop at the first incomplete zlib stream.

This recovers another **24 `wip` commits**, again starting from `87c3d0c`. They don't appear in the reflog or on any branch, and only exist in the half-written pack. Walk from the tip `6c677db1` back to `87c3d0c` and join each commit's `part` blob:

```
1f8b080000000000020a2bc8284a2c4eb552f0f30ff1f0f47357f00c56700d730d527071f5710d7175e102006a56a06720000000
```

Gunzipped: `phrase: NOTHING IS EVER DELETED`

```bash
python3 unlock.py "NOTHING IS EVER DELETED"
# GPI{d4ngl1ng_c0mm1ts_n3v3r_r34lly_l34v3_7a3e}
```

### Pack-parsing script

```python
import sys, zlib, hashlib, gzip, subprocess

pack, gitdir = sys.argv[1], sys.argv[2]   # tmp_pack_568fed, harbour.git
d = open(pack, 'rb').read()
T = {1: 'commit', 2: 'tree', 3: 'blob', 4: 'tag'}
objs, p = {}, 12
for _ in range(int.from_bytes(d[8:12], 'big')):
    if p >= len(d): break
    c = d[p]; t = (c >> 4) & 7; p += 1
    while c & 0x80: c = d[p]; p += 1
    z = zlib.decompressobj(); body = z.decompress(d[p:])
    if not z.eof: break                       # truncated object
    p = len(d) - len(z.unused_data)
    h = hashlib.sha1(f'{T[t]} {len(body)}\0'.encode() + body).hexdigest()
    objs[h] = body

def get(h, kind):
    if h in objs: return objs[h]
    return subprocess.run(['git', '--git-dir=' + gitdir, 'cat-file', kind, h],
                          capture_output=True, check=True).stdout

def tree(b):
    out, i = {}, 0
    while i < len(b):
        j = b.index(b' ', i); k = b.index(b'\0', j)
        out[b[j+1:k].decode()] = b[k+1:k+21].hex(); i = k + 21
    return out

h = next(k for k in objs if k.startswith('6c677db1'))
chain = []
while h != '87c3d0c5388dc155ece82df7fcc6306a3213012c':
    chain.append(h); h = objs[h].decode().split('parent ')[1][:40]

data = b''
for c in reversed(chain):
    t = tree(get(objs[c].decode().split()[1], 'tree'))
    data += get(t['part'], 'blob')
print(gzip.decompress(data))   # b'phrase: NOTHING IS EVER DELETED\n'
```

## Which flag to submit

| Layer | Source | Flag |
|---|---|---|
| 1 | `secret.txt` (Base64) | `GPI{0ld_3nc0d1ngs_d13_h4rd_l00k_4t_th3_l4st_byt3s_74f9}` |
| 2 | reflog `scratch` branch → `CHECK THE REFLOG` | `GPI{th3_l0gs_r3m3mb3r_bl1nd_sp0ts_3v3rywh3r3_f3fa}` |
| 3 | dangling commits in `tmp_pack` → `NOTHING IS EVER DELETED` | `GPI{d4ngl1ng_c0mm1ts_n3v3r_r34lly_l34v3_7a3e}` |

Layer 3 is most likely the real flag. The description says they were thorough "by their own account", which suggests they cleared the obvious places (the history and the reflog clue), but the half-written pack still held the real data. `unlock.py` has two boxes, one for each phrase, which fits a decoy plus a real answer. If layer 3 is rejected, try layer 2, then layer 1.

**Takeaways:** deleting a branch or rewriting history doesn't remove git objects. They stay in packs, the reflog and leftover `tmp_pack_*` files until the repo is properly cleaned (`git reflog expire --expire=now --all && git gc --prune=now`). Even a truncated pack can be read one object at a time.
