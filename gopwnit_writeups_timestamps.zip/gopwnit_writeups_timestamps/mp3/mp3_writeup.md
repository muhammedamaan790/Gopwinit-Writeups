---
title: "mp3"
ctf: "Unspecified"
date: 2026-10-10
category: forensics
difficulty: medium
points: 100
flag_format: "FLAG{...}"
author: "bhaiya_ji"
---

# Omnitrix Signal

## Summary

The MP3 contains useful ID3 metadata, a spectrogram message, a Morse-encoded right-channel subcarrier, and an encrypted payload appended after the final MP3 frame. The two recovered fragments form the AES-256-CBC key.

## Solution

### Step 1: Inspect metadata and the appended payload

`exiftool` reveals the extraction recipe:

```text
SHA256(Spectrogram_Visual || ':' || Right_Channel_Subcarrier)
AES-256-CBC (IV = first 16 bytes)
```

The EOF marker contains this Base64 ciphertext:

```text
teOwuOZwl1If8Z5NT1NGB/m+kwFQkVYLkHTIZMdZaIJfX2+TyDfiVNdEv2PcmRhds8u/HqtV1l+Fd+u6e2BqjA==
```

### Step 2: Recover both key fragments

Split the stereo channels with `ffmpeg` and generate a high-resolution spectrogram. The visible text is:

```text
HERO_10
```

Subtracting the channels isolates a roughly 650 Hz Morse carrier. Reading the Morse stream backwards (including reversing each character) gives:

```text
OMNITRIX
```

### Step 3: Derive the key and decrypt

The following script starts from the MP3 and prints the flag. It uses the exact decoded IV bytes; the final byte is `07`.

```python
#!/usr/bin/env python3
import base64
import hashlib
import re
import subprocess
import sys

mp3 = open(sys.argv[1], "rb").read()
m = re.search(
    rb"---OMNITRIX_PAYLOAD_START---\s*"
    rb"([A-Za-z0-9+/=]+)\s*---OMNITRIX_PAYLOAD_END---",
    mp3,
)
if not m:
    raise SystemExit("payload marker not found")

blob = base64.b64decode(m.group(1))
iv, ciphertext = blob[:16], blob[16:]
key = hashlib.sha256(b"HERO_10:OMNITRIX").hexdigest()

plain = subprocess.check_output(
    [
        "openssl", "enc", "-aes-256-cbc", "-d",
        "-K", key, "-iv", iv.hex(),
    ],
    input=ciphertext,
)
print(plain.decode())
```

## Flag

```text
FLAG{b3n_10_0mn1tr1x_4ud10_f0r3ns1cs_m4st3r}
```
