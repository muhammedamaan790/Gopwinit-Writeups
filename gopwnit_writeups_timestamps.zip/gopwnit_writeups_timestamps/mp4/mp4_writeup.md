# mp4 — Writeup

**Category:** Steganography · **Difficulty:** Medium · **Points:** 100 · **Author:** BHAIYA_JI

**Flag:** `FLAG{the_last_transmission}`

## Challenge

> An emergency deep-space telemetry recording was intercepted from a silent orbital relay station. Investigate the container metadata, analyze the high-frequency audio spectrogram, and isolate the hidden stereo channel clues to extract the concealed carrier frequency signal to reconstruct the final mission flag.

Attachment: `player_package.zip` → `last_transmission.mp4` (AAC, 44.1 kHz, stereo, 19.66 s, no video stream)

## 1. Container metadata

```bash
ffprobe -hide_banner last_transmission.mp4
```

The `encoder`, `comment` and `description` tags all carry the same hex string:

```
7363616e20746865207370656374726f6772616d  →  "scan the spectrogram"
```

## 2. Spectrogram

```bash
ffmpeg -i last_transmission.mp4 a.wav
```

A spectrogram of either channel shows the text **`SECOND_CHANNEL`** drawn at about 14–16 kHz, between 2 s and 17 s.

It also shows:
- **Left channel:** two steady tones at **1920 Hz** and **2000 Hz** that alternate (from 1.0 s to 15.8 s).
- **Right channel:** an extra **2400 Hz** tone that switches on and off. It stands out clearly in `L − R`.

## 3. Right channel: Morse code at 2400 Hz

Band-pass filter `L − R` around 2400 Hz, take the envelope and measure how long the tone stays on and off:

| Element | Duration |
|---|---|
| dot | ~150 ms |
| dash | ~450 ms |
| gap between dots/dashes | ~150 ms |
| gap between letters | ~450 ms |
| gap between words | ~2000 ms |

```
.---- ----. ..--- -----  /  .---- ----…
  1     9     2     0         1    (cut off where the file ends)
```

The Morse gives **1920**, the carrier frequency of the hidden data signal in the left channel.

## 4. Left channel: two-tone FSK at 1920 / 2000 Hz

Get the envelope of each tone (band-pass ±30 Hz, then a Hilbert transform, then a low-pass filter) and compare them over time:

- Signal runs from 1.0 s to 15.8 s, about **14.8 s**
- Shortest run of either tone is **50 ms**, so the rate is **20 baud**
- 14.8 s / 0.05 s = **296 bits = 37 bytes**
- Bit mapping: 2000 Hz = `1`, 1920 Hz = `0`, read most significant bit first

Decoded bytes:

```
\xaa RkxBR3t0aGVfbGFzdF90cmFuc21pc3Npb259
```

`0xAA` (`10101010`) is a sync byte at the start. The rest is Base64:

```bash
echo RkxBR3t0aGVfbGFzdF90cmFuc21pc3Npb259 | base64 -d
# FLAG{the_last_transmission}
```

## Solver script

```python
import numpy as np, scipy.io.wavfile as w, scipy.signal as s, base64

sr, d = w.read('a.wav')            # ffmpeg -i last_transmission.mp4 a.wav
L = d[:, 0].astype(float)

def env(x, f0, bw=30):
    b, a = s.butter(4, [f0 - bw, f0 + bw], 'bandpass', fs=sr)
    y = s.filtfilt(b, a, x)
    return s.filtfilt(*s.butter(2, 150, fs=sr), np.abs(s.hilbert(y)))

e0, e1 = env(L, 1920), env(L, 2000)
start, T, n = int(1.0 * sr), 0.05 * sr, 296
bits = ''.join('1' if e1[int(start + (i + .5) * T)] > e0[int(start + (i + .5) * T)] else '0'
               for i in range(n))
data = bytes(int(bits[i:i + 8], 2) for i in range(0, n, 8))
print(data)                         # b'\xaaRkxBR3t0aGVfbGFzdF90cmFuc21pc3Npb259'
print(base64.b64decode(data[1:]))   # b'FLAG{the_last_transmission}'
```

## Flag

```
FLAG{the_last_transmission}
```
