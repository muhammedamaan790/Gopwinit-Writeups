# Paper Jam: writeup

**Category:** Miscellaneous · **Difficulty:** Easy · **Points:** 50 · **Author:** GOPWNIT

**Flag (most likely):** `GPI{1ncr3m3nt4l_upd4t3s_k33p_th3_0ld_p4g3_a9d3}`

## Challenge

> The final berth allocation notice from the harbour authority, one page, perfectly ordinary.

Attachment: `dist.zip` contains:
- `notice.pdf`: a one-page PDF
- `unlock.py`: an answer checker that asks for "the phrase". It has **two** answer boxes, so one phrase is a decoy.

## 1. The PDF has two versions (incremental update)

Opening `notice.pdf` as text shows two `%%EOF` markers. The file was edited with an **incremental update**: the new version of object `4 0 obj` (the page content) was added after the first `%%EOF`, together with a new xref table and a trailer containing `/Prev 1243`. PDF viewers show only the newest version, but the original bytes are still in the file.

Visible (FINAL) page content:

```
Harbour authority - berth allocations - FINAL
Nothing was changed between drafts.
ref R1BJe3RoM19sMGdzX3IzbTNtYjNyX2M0Y2gzZF9jMHAxM3NfbDF2M18wbl8wYzhlfQ==
```

The `ref` value Base64-decodes to `GPI{th3_l0gs_r3m3mb3r_c4ch3d_c0p13s_l1v3_0n_0c8e}`. That's **decoy #1**: it sits in plain view and its wording ("the logs remember", the same style as decoys in other challenges) has nothing to do with this file.

## 2. Recovering the original draft

The original object 4 is encoded with `/Filter [/ASCII85Decode /FlateDecode]`:

```python
import re, zlib, base64
d = open('notice.pdf', 'rb').read()
for m in re.finditer(rb'(\d+) 0 obj\s*<<(.*?)>>\s*stream\r?\n(.*?)\r?\nendstream', d, re.S):
    n, h, s = m.groups()
    if b'ASCII85' in h: s = base64.a85decode(s.strip(), adobe=True)
    if b'Flate'   in h: s = zlib.decompress(s)
    print(n, s.decode('latin1'))
```

Original DRAFT content:

```
BT /F1 12 Tf 72 720 Td (Harbour authority - berth allocations - DRAFT) Tj ET
BT /F2 14 Tf 3 Tr
1 0 0 1 72 640 Tm <06> Tj
1 0 0 1 193 640 Tm <08> Tj
1 0 0 1 149 640 Tm <03> Tj
...
```

Three tricks are layered in it:
1. **`3 Tr`** sets the text rendering mode to *invisible*, so nothing is drawn even in the draft.
2. Each character is placed with its own `Tm` (absolute position) and the commands are **out of order**. Reading them in file order gives nonsense; they have to be sorted by x coordinate (72, 83, 94, … 226, 11 units apart).
3. Font `F2` maps each byte to **two different characters**:
   - `/Encoding … /Differences` decides which **glyph is drawn**
   - `/ToUnicode` CMap decides what **copy-paste or text extraction** returns

## 3. Decoding both mappings

Sorted by x:

| x | code | Glyph (`/Differences`) | ToUnicode |
|---|---|---|---|
| 72 | 06 | T | C |
| 83 | 0B | H | O |
| 94 | 09 | E | P |
| 105 | 0C | ␣ | Y |
| 116 | 04 | F | ␣ |
| 127 | 0F | I | A |
| 138 | 0A | R | N |
| 149 | 03 | S | D |
| 160 | 05 | T | ␣ |
| 171 | 07 | ␣ | P |
| 182 | 02 | D | A |
| 193 | 08 | R | S |
| 204 | 01 | A | T |
| 215 | 0E | F | E |
| 226 | 0D | T | ␣ |

- Glyphs drawn: **`THE FIRST DRAFT`**
- Text extraction / copy-paste: **`COPY AND PASTE`**

## 4. Unlock

```bash
python3 unlock.py "THE FIRST DRAFT"
# GPI{1ncr3m3nt4l_upd4t3s_k33p_th3_0ld_p4g3_a9d3}

python3 unlock.py "COPY AND PASTE"
# GPI{tr41l1ng_d4t4_t3lls_t4l3s_0p3n_s0urc3_1nt3l_w1ns_c7b6}
```

## Which flag to submit

| Source | Flag | Verdict |
|---|---|---|
| Base64 `ref` in the visible FINAL page | `GPI{th3_l0gs_r3m3mb3r_c4ch3d_c0p13s_l1v3_0n_0c8e}` | decoy |
| ToUnicode text (what `pdftotext` or copy-paste gives) → `COPY AND PASTE` | `GPI{tr41l1ng_d4t4_t3lls_t4l3s_0p3n_s0urc3_1nt3l_w1ns_c7b6}` | decoy: the trap for anyone who just extracts the text |
| Drawn glyphs of the original draft → `THE FIRST DRAFT` | `GPI{1ncr3m3nt4l_upd4t3s_k33p_th3_0ld_p4g3_a9d3}` | **real**: describes the actual technique ("incremental updates keep the old page") |

## Flag

```
GPI{1ncr3m3nt4l_upd4t3s_k33p_th3_0ld_p4g3_a9d3}
```

**Takeaway:** "Nothing was changed between drafts" is false. An incremental update appends a replacement object but leaves the old one in the file. And PDF text can look one way on screen while extracting as something else, because the drawn glyphs and the ToUnicode map are separate.
