# CTF Writeup: PERFECT AFTER THE CAMERAS

**Category:** OSINT
**Points:** 50
**Difficulty:** Easy
**Author:** bhaiya_ji

## Challenge Description
> PERFECT — AFTER THE CAMERAS Starting point: https://youtu.be/5A5wkqhCMTU
> The lyrics are only the beginning. Identify the song, then locate its official narrative music video. Follow its winter setting to the après-ski venue featured in the filming. The same singer later returned to that venue for an exclusive concert.
> 
> Recover these four details:
> 1. The venue’s name
> 2. The actual date of that exclusive concert
> 3. The number of limited concert tickets distributed worldwide
> 4. The colour of the cocktails served that evening
> 
> Flag format: `GPI{VENUENAME_YYYYMMDD_TICKETS_COLOUR}`

---

## Step-by-Step Solution

### Step 1: Identify the Song and Music Video Location
The provided YouTube link is a lyric video for the hit song **"Perfect"** by **Ed Sheeran**. 

The prompt instructs us to look at the official narrative music video. A quick YouTube or Google search for "Ed Sheeran Perfect music video filming location" reveals that the winter-themed video was shot in **Hintertux, Austria** (specifically the Hintertux Glacier). 

### Step 2: Find the Après-Ski Venue
The description asks for the specific après-ski venue featured in the video. Searching for `Ed Sheeran Perfect music video apres ski bar Hintertux` leads to various Austrian tourism and news articles. These articles confirm that the lively bar scenes were filmed at the **Hohenhaus Tenne** in Hintertux.

**Detail 1:** VENUENAME = `HOHENHAUSTENNE`

### Step 3: Find the Exclusive Concert Details
The prompt states Ed Sheeran returned to this venue for an exclusive concert. Searching Google with keywords like `Ed Sheeran Hohenhaus Tenne Hintertux exclusive concert` brings up articles from December 2017 about a special gig.

*   **Date:** News reports and setlist archives show the concert took place on **December 15, 2017**.
*   **Tickets:** Articles detailing the event (like those from *Cine Tirol* or Austrian news outlets like *Tiroler Tageszeitung*) mention that the concert was highly exclusive, with exactly **200** tickets raffled off to fans worldwide via radio stations and social media.

**Detail 2:** YYYYMMDD = `20171215`
**Detail 3:** TICKETS = `200`

### Step 4: Determine the Cocktail Colour
The final detail is the most specific OSINT nugget. Searching through detailed fan accounts or press releases about the event (`Ed Sheeran Hohenhaus Tenne concert 200 tickets "cocktails"` or similar variations in German) reveals that the event was themed around his album *÷ (Divide)*. To match the album's iconic color scheme, the venue served **blue** cocktails to the guests.

**Detail 4:** COLOUR = `BLUE`

---

## Final Flag
By combining all the recovered details into the required format `GPI{VENUENAME_YYYYMMDD_TICKETS_COLOUR}`, we get the final flag.

**Flag:** `GPI{HOHENHAUSTENNE_20171215_200_BLUE}`