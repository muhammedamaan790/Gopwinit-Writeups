# Phantom Hands: writeup

**Category:** Forensics · **Difficulty:** Easy · **Points:** 50 · **Author:** GOPWNIT

**Flag:** `GPI{dv0r4k_h4nds_4nd_4_m0us3_th4t_dr4ws_60c9}`

## Challenge

> A hardware tap sat on a suspect's USB hub for a few minutes. Somewhere in this session a secret was unlocked, and nobody typed the passphrase.

Attachment: `dist.zip` → `usb.pcap` (Linux usbmon capture, 2158 frames)

## 1. Devices in the capture

```bash
tshark -r usb.pcap -T fields -e usb.device_address -e usb.endpoint_address -e usb.data_len | sort | uniq -c
```

| Device | Reports | Report size | What it is |
|---|---|---|---|
| 3 | 496 | 8 bytes | the suspect's keyboard |
| 7 | 88 | 8 bytes | a second keyboard (injected, active 14.9–21.3 s) |
| 5 | 1574 | 4 bytes | a mouse (active 48.1–60.7 s) |

```bash
tshark -r usb.pcap -T fields -e frame.time_relative -e usb.device_address -e usb.capdata > reports.tsv
```

## 2. Keyboard 3: a layout switch

Decoding the HID usage IDs with a **QWERTY** table gives:

```
echo GPI{k3yb04rd_pc4ps_4r3_4_s0lv3d_pr0bl3m_b3a2}     ← decoy
setxkbmap dvorak                                        ← layout switch at 12.27 s
rtjksl⌫⌫⌫⌫kjsl3 fl;dpert←←←←a<End> 626822313i1y6196i...
```

USB keyboards send **key positions**, not characters. The host's layout turns them into characters. After `setxkbmap dvorak`, every keystroke has to be mapped through **Dvorak**:

```
qwerty: qwertyuiop[]  asdfghjkl;'  zxcvbnm,./  -=
dvorak: ',.pyfgcrl/=  aoeuidhtns-  ;qjkxbmwvz  []
```

Replaying the line with Backspace, Left-arrow and End handled properly:

```
python3 unseal.py 626822313c1f6196c622999c35fb4dde83aababf62c901ddfe04682138cbb223f8a2362ed9cd54117456fa9650137cdad9a2d6862f881c600457179f7d561d148b6c0ebd060fae3dbc
```

(`pyhton`, backspaced to `py`, becomes `python3`. `unsel.py` gets the `a` inserted after moving the cursor left 4 times, giving `unseal.py`. In QWERTY the hex string looked like it had letters `i y n h d`; those are really `c f b d e`.)

## 3. Keyboard 7: the "phantom" keyboard (decoy)

Device 7 appears briefly, as a BadUSB or Rubber Ducky would, and in QWERTY its keystrokes read:

```
GPI{th3_0th3r_k3yb04rd_typ3d_th1s_0n3_94f6}
```

It fired at 14.9–21.3 s, **after** the switch to Dvorak, so the host actually received `ILC?yd3{0yd3p{t3fx04pe{yfl3e{yd1o{0b3{94u6+`. Either way it's a decoy and isn't the passphrase.

## 4. The mouse: the passphrase nobody typed

Add up the relative X/Y movement of the 4-byte mouse reports (`[buttons, dx, dy, wheel]`, dx/dy are signed bytes) and draw only while the left button (`buttons & 1`) is held:

```python
x = y = 0; segs = []; cur = []
s = lambda v: v - 256 if v > 127 else v
for b in mouse_reports:
    nx, ny = x + s(b[1]), y + s(b[2])
    if b[0] & 1:
        cur = cur or [(x, y)]; cur.append((nx, ny))
    elif cur:
        segs.append(cur); cur = []
    x, y = nx, ny
# plot each segment, with y flipped
```

The strokes spell:

```
TALLOW-RIVET-83
```

## 5. Unseal

The ciphertext is 73 bytes: `nonce[12] | AES-256-GCM ciphertext+tag`, with key = `SHA256(passphrase)`. That's the same scheme as the other GOPWNIT challenges.

```python
import hashlib
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

ct  = bytes.fromhex('626822313c1f6196c622999c35fb4dde83aababf62c901ddfe04682138cbb223f8a2362ed9cd54117456fa9650137cdad9a2d6862f881c600457179f7d561d148b6c0ebd060fae3dbc')
key = hashlib.sha256(b'TALLOW-RIVET-83').digest()
print(AESGCM(key).decrypt(ct[:12], ct[12:], None))
# b'GPI{dv0r4k_h4nds_4nd_4_m0us3_th4t_dr4ws_60c9}'
```

The GCM tag check passes, so the flag is confirmed.

## Decoys

| Source | Flag |
|---|---|
| keyboard 3 `echo` line | `GPI{k3yb04rd_pc4ps_4r3_4_s0lv3d_pr0bl3m_b3a2}` |
| keyboard 7 (QWERTY reading) | `GPI{th3_0th3r_k3yb04rd_typ3d_th1s_0n3_94f6}` |

## Flag

```
GPI{dv0r4k_h4nds_4nd_4_m0us3_th4t_dr4ws_60c9}
```
