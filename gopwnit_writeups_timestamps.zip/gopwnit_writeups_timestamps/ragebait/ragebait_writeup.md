---
title: "Ragebait"
ctf: "Unknown / local challenge"
date: 2026-10-10
category: misc
difficulty: hard
points: 150
flag_format: "GPI{...}"
author: "gopwnit"
---

# Ragebait

## Summary

The challenge is a Go PE binary disguised as a Linux executable. It contains several deliberately planted flag-shaped strings, but only one is referenced by the main validation path.

## Solution

### Step 1: Identify the real validation branch

Both provided binaries are PE32+ Go executables despite one being named `golev_linux_amd64`. Static disassembly of `main.main` shows this check:

```asm
cmp    rbx,0x28
lea    rbx,[rip+...]        # GPI{b3y0nd_41_l0g1c_r3c0nstruct10n_9f82}
call   memcmp-like routine
```

The candidate is exactly 40 bytes long. On a match, the program calls `GetBinaryRuntimeHash` and later formats the same candidate using `OFFICIAL TOURNAMENT FLAG: %s`.

Several other strings are decoys. For example, the 37-byte `g0_l3v_3g0_sh4tt3r3d...` value is sent directly to an AI-trap message, while the 45-byte `g0_l3v_3g0_ch3ck...` value is used as the oracle honeypot.

The following script extracts the binary, locates all flag-shaped strings, and selects the 40-byte value referenced by a RIP-relative `lea` in the executable code:

```python
#!/usr/bin/env python3
import re
import struct
import sys
import zipfile

archive = sys.argv[1] if len(sys.argv) > 1 else "1791635369181-dist.zip"

with zipfile.ZipFile(archive) as zf:
    exe_name = next(name for name in zf.namelist()
                    if name.endswith("golev_linux_amd64"))
    blob = zf.read(exe_name)

# PE section layout from objdump -h.
TEXT_VA, TEXT_RAW = 0x140001000, 0x600
RDATA_VA, RDATA_RAW = 0x1400CC000, 0xCB600

for match in re.finditer(rb"GPI\{[^\x00\r\n]{1,100}\}", blob):
    flag = match.group()
    if len(flag) != 40:
        continue

    target_raw = match.start()
    target_va = RDATA_VA + target_raw - RDATA_RAW

    # Find a 64-bit RIP-relative LEA whose target is this string.
    for ins_raw in range(TEXT_RAW, RDATA_RAW, 1):
        if blob[ins_raw:ins_raw + 3] != b"\x48\x8d\x1d":
            continue
        disp = struct.unpack_from("<i", blob, ins_raw + 3)[0]
        ins_va = TEXT_VA + ins_raw - TEXT_RAW
        referenced_va = ins_va + 7 + disp
        if referenced_va == target_va:
            print(flag.decode())
            raise SystemExit

raise SystemExit("real flag reference not found")
```

## Flag

```text
GPI{b3y0nd_41_l0g1c_r3c0nstruct10n_9f82}
```
