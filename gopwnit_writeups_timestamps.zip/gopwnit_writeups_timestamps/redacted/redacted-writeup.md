# redacted (OSINT, 50 pts, Easy): Writeup

**Flag:** `GPI{tr4ck3d_ch4ng3s_4nd_thumbn41ls_n3v3r_f0rg3t_1c8e}`

## Challenge

> A freight company's internal briefing leaked. The names are blacked out and the photo has been tidied up. You also have the staff directory.

The zip `dist.zip` contains:

- `briefing.docx`: the leaked briefing
- `staff_directory.csv`: 10,000 staff entries (`badge,full_name,department,site`)
- `unlock.py`: an answer checker that asks three questions and decrypts the flag if all three answers are right

The checker's questions:

1. Full name of the source, as originally written
2. Full name of the staff member whose badge was at the desk
3. Gate where the meeting really takes place

The checker derives a key from the answers with scrypt (n=2^17), so brute-forcing it isn't practical. The answers have to be recovered from the files.

## Recon

A `.docx` file is a zip archive, so unzip it and read the XML:

```bash
unzip briefing.docx -d docx
cat docx/word/document.xml
cat docx/docProps/core.xml
```

## Q1: The source's real name (Track Changes)

In `document.xml` the "redacted" name is a tracked change:

```xml
<w:del w:author="R. Stroud" ...>
  <w:delText>Mi</w:delText><w:delText>na Thac</w:delText><w:delText>keray</w:delText>
</w:del>
<w:ins w:author="R. Stroud" ...>
  <w:rPr><w:color w:val="000000"/><w:highlight w:val="black"/></w:rPr>
  <w:t>Cato Ingram</w:t>
</w:ins>
```

The original name was deleted with Track Changes on, so it's still stored in the file. It is split across three runs so a plain `grep` won't find it. The name inserted in its place, **Cato Ingram**, is only covered with black highlighting, and that is the decoy.

**Answer: `Mina Thackeray`**

## Q3: The real gate (hidden text)

The visible paragraph says:

```
Meeting point: gate C-04, 07:00.
```

The next paragraph has `<w:vanish/>` set, which makes it hidden text that Word doesn't display:

```xml
<w:rPr><w:vanish/></w:rPr>
<w:t>Correction, not for circulation: gate G-17, 06:15.</w:t>
```

**Answer: `G-17`**

## Q2: The badge on the desk (leftover EXIF thumbnail)

The photo `word/media/image1.jpg` (800×800) shows a monitor reading `MANIFEST 0417 / HOLD`, a keyboard and a mug. Nothing else is visible because the image was edited.

Scanning the file for JPEG start markers finds a second one:

```python
d = open('image1.jpg', 'rb').read()
[m.start() for m in re.finditer(b'\xff\xd8', d)]   # -> [0, 152]
```

The match at offset 152 is the EXIF thumbnail (480×320). The editor that cleaned up the main image didn't regenerate it, so it still shows the original scene:

```python
e = d.find(b'\xff\xd9', 152)
open('thumb.jpg', 'wb').write(d[152:e+2])
```

(`exiftool -b -ThumbnailImage image1.jpg > thumb.jpg` also works.)

The thumbnail shows a lanyard badge reading **MARLOWE FREIGHT / STAFF / B-18807**. Look it up in the directory:

```bash
$ grep "^B-18807," staff_directory.csv
B-18807,Rhea Vance,Security,Depot 3
```

The badge number appears only once. "Mina Thackeray" and "Cato Ingram" each appear several times in the directory, which is why the badge number is the reliable identifier here.

**Answer: `Rhea Vance`**

## Decoys

- `docProps/core.xml` has a base64 string in `dc:description`:
  ```
  R1BJe2JsNGNrX2gxZ2hsMWdodF8xc19uMHRfcjNkNGN0MTBuX2YzYjB9
  -> GPI{bl4ck_h1ghl1ght_1s_n0t_r3d4ct10n_f3b0}
  ```
  This flag is fake. It's there to catch people who only check the metadata.
- `unlock.py` contains two encrypted results. One is the real flag. The other is most likely the reward for the decoy answers (Cato Ingram and C-04).
- Other metadata: the author is Lars Fenwick and the EXIF camera is "Orbit Pocket 7". None of it is needed.

## Solve

```bash
$ python3 unlock.py "Mina Thackeray" "Rhea Vance" "G-17"
GPI{tr4ck3d_ch4ng3s_4nd_thumbn41ls_n3v3r_f0rg3t_1c8e}
```

## Takeaways

- **A black highlight is not redaction.** The text under it is still in the file.
- **Track Changes keeps deleted text.** Accept all changes and inspect the document before sharing it.
- **Hidden text (`w:vanish`) stays in the file.** It is not displayed, but anyone reading the XML sees it.
- **EXIF thumbnails can outlive edits.** Remove metadata (`exiftool -all= img.jpg`) after cropping or retouching a photo.
