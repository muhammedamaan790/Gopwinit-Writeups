# Saltcellar: writeup

**Category:** Cryptography · **Difficulty:** Medium · **Points:** 100 · **Author:** GOPWNIT

**Flag:** `GPI{th3_b14s_w4s_4_mult1pl3_n0t_4_sh1ft}`

Confirmed: the recovered private key regenerates the published public key, and decrypting `flag.enc` with it yields clean text.

## Challenge

> Forty signatures from one key. The nonce is a randomised counter reading scaled back onto the counter grid, so it stays on a step boundary for the audit trail. Full-width either way, so nothing is lost. You won't need all forty, and extra isn't free.

Handout:
- `signatures.txt`: secp256k1 public key + 40 ECDSA signatures `(r, s)` over known messages
- `signer.py`: the signing routine
- `notes.md`: parameters
- `flag.enc`: the flag XORed with a keystream derived from the private key

## The nonce bias

From `signer.py`:

```python
STEP = 0x9E3779B97F4A7C15          # odd, 64-bit
RANDOM_BITS = 192
def nonce():
    while True:
        k = STEP * secrets.randbits(192)
        if 1 <= k < N:
            return k
```

So every nonce is `k = STEP · x` with `x` a 192-bit random value. The notes spell it out: the nonce is a full-width 256-bit value but **always a multiple of `0x9E3779B97F4A7C15`**, which "costs it 64 bits of range out of 192 random ones."

`STEP` is odd, so it is invertible mod the curve order `N`. Therefore:

```
x = k · STEP⁻¹  (mod N),   with  0 ≤ x < 2¹⁹²
```

The quantity `k·STEP⁻¹` is 64 bits short of full width. That is exactly the leakage needed for a **hidden number problem (HNP)** lattice attack — the same attack used against biased/partially-known ECDSA nonces, except the bias here is a *multiplicative* factor rather than fixed high/low bits (hence the flag).

## Setting up the HNP

ECDSA: `s = k⁻¹ (h + r·d) mod N`, so `k = s⁻¹(h + r·d) mod N`.

Multiply by `STEP⁻¹` and write `x = k·STEP⁻¹`:

```
x_i = t_i · d + u_i  (mod N)
  t_i = s_i⁻¹ · r_i · STEP⁻¹  (mod N)
  u_i = s_i⁻¹ · h_i · STEP⁻¹  (mod N)
  h_i = SHA256(message_i)  mod N
```

with the unknown private key `d` and each `x_i` bounded by `B = 2¹⁹²`.

## Lattice

Embed the HNP as a short-vector problem. For `m` signatures, build the `(m+2) × (m+2)` basis (centering each `x_i` around `B/2` with `u'_i = u_i − B/2`):

```
[ N·I_m                 0        0 ]
[ t_1 … t_m           B/N        0 ]
[ u'_1 … u'_m           0        B ]
```

The combination `(−k_1, …, −k_m, d, 1)` produces the short lattice vector

```
( x_1−B/2, …, x_m−B/2,  d·B/N,  B )
```

whose entries are all ≈ `B`. After LLL reduction, the row whose last coordinate is `±B` gives `d = (second-to-last coordinate)·N / B`. Verify by checking `d·G == public key`.

With 64 bits of leakage against a 256-bit `N`, the theoretical minimum is `256/64 = 4` signatures; **5 are enough** in practice. "Adding more than you need is not free" — extra signatures just enlarge the lattice and slow reduction without helping.

## Solver

```python
import re, hashlib
from fractions import Fraction as F

N = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141
STEP = 0x9E3779B97F4A7C15
B = 1 << 192

# parse public key + signatures, compute h_i = sha256(msg) mod N
# t_i = s_i^-1 * r_i * STEP^-1 ; u_i = s_i^-1 * h_i * STEP^-1   (all mod N)

def solve(idxs):          # idxs = list of signature indices (len m)
    si = pow(STEP, -1, N)
    t = [pow(s, -1, N) * r * si % N for (h, r, s) in sigs_sub]
    u = [pow(s, -1, N) * h * si % N for (h, r, s) in sigs_sub]
    m = len(idxs); half = B // 2
    uu = [(u[i] - half) % N for i in range(m)]
    M = [[F(0)] * (m + 2) for _ in range(m + 2)]
    for i in range(m): M[i][i] = F(N)
    for i in range(m): M[m][i] = F(t[i])
    M[m][m] = F(B, N)
    for i in range(m): M[m+1][i] = F(uu[i])
    M[m+1][m+1] = F(B)
    for row in lll(M):                      # exact rational LLL
        if row[-1] == 0: continue
        sign = 1 if row[-1] > 0 else -1
        d = row[-2] * sign * N / B
        if d.denominator == 1:
            d = int(d) % N
            if scalar_mult(d, G) == pubkey:  # secp256k1 check
                return d

d = solve(range(5))
ks = hashlib.sha256(d.to_bytes(32, "big")).digest()
ct = bytes.fromhex(open("flag.enc").read().strip())
print(bytes(ct[i] ^ ks[i % len(ks)] for i in range(len(ct))))
# b'GPI{th3_b14s_w4s_4_mult1pl3_n0t_4_sh1ft}'
```

Recovered key:

```
d = 0x5005554fa55b9e811a71e69c7caa0ad95768469ef5e8b363b363b2a77dfddc2f
```

(`d·G` matches `public_key_x/y`, so the key is certainly correct.)

## Decrypting the flag

From `notes.md`, the flag was XORed byte-by-byte with `sha256(d.to_bytes(32,"big")).digest()` repeated to length.

```
GPI{th3_b14s_w4s_4_mult1pl3_n0t_4_sh1ft}
```

## Flag

```
GPI{th3_b14s_w4s_4_mult1pl3_n0t_4_sh1ft}
```

**Takeaway:** a nonce doesn't have to leak its top or bottom bits to be fatal. Any affine/multiplicative structure that confines it to a sublattice (here, a fixed odd multiple) is HNP-exploitable. The flag name says it: the bias was a multiple, not a shift.
