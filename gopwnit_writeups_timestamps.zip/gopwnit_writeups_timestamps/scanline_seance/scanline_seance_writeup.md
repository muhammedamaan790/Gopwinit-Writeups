# scanline-seance: writeup

**Category:** Steganography · **Difficulty:** Easy · **Points:** 50 · **Author:** GOPWNIT

**Flag:** `GPI{th3_r0ws_r3m3mb3r_h0w_th3y_w3r3_wr1tt3n_3a7c}`

## Challenge

> The picture is a lie, but the way it was written down is not.

Attachment: `dist.zip` → `seance.png` (900×2048, 8-bit RGB)

The hint means the pixels are irrelevant. What matters is **how the PNG was encoded**: its chunk layout and the filter type chosen for each row.

## Decoys

```bash
exiftool seance.png
```

| Where | Content | Verdict |
|---|---|---|
| `tEXt Comment` | Base64 → `GPI{th3_c0mm3nt_f13ld_n3v3r_sl33ps_5b21}` | decoy |
| `tEXt Passphrase` | `candle-and-bell-1692` | decoy (doesn't decrypt anything) |
| 174 bytes after `IEND` | a ZIP containing `recovered/flag.txt` → `GPI{wh4t_f0ll0ws_th3_3nd_1s_n0t_th3_3nd_90cd}` | decoy |

## 1. IDAT chunk sizes, which give the key

Listing the chunks shows 23 IDAT chunks. The first 22 are tiny and the last holds almost all the image data. The sizes of the tiny chunks are ASCII codes:

```python
import struct
d = open('seance.png', 'rb').read(); p = 8; sizes = []
while p < len(d):
    ln, = struct.unpack('>I', d[p:p+4]); t = d[p+4:p+8]
    if t == b'IDAT': sizes.append(ln)
    p += 12 + ln
    if t == b'IEND': break
print(sizes)             # [119, 114, 49, 116, ..., 115, 4526192]
print(bytes(sizes[:-1])) # b'wr1tt3n-1n-th3-m4rg1ns'
```

**Key phrase:** `wr1tt3n-1n-th3-m4rg1ns` ("written in the margins")

## 2. Row filter types, which give the ciphertext

Every PNG row starts with a filter-type byte (0 = None, 1 = Sub, 2 = Up, 3 = Average, 4 = Paeth). An encoder normally picks the filter that compresses best. Here only values **0–3** are used, spread roughly evenly (510 / 507 / 502 / 529). That's 4 symbols, so **2 bits per row**: 2048 rows × 2 bits = 4096 bits = 512 bytes.

```python
import zlib
idat = b''.join(...)                       # all IDAT payloads joined
raw = zlib.decompress(idat)
W, H = 900, 2048; stride = W * 3 + 1
f = [raw[i * stride] for i in range(H)]   # filter byte of each row
data = bytes(sum(f[i + j] << (6 - 2 * j) for j in range(4)) for i in range(0, H, 4))
# data[:2] = 00 4d  → L = 77
```

## 3. Decrypt

The layout is the same as in Fouriers-ghost: `u16be L | nonce[12] | AES-256-GCM(ciphertext+tag)`, where **L counts the nonce together with the ciphertext** (77 = 12 + 65).

```python
import hashlib
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

L     = int.from_bytes(data[:2], 'big')  # 77
nonce = data[2:14]
ct    = data[14:2 + L]                   # 65 bytes
key   = hashlib.sha256(b'wr1tt3n-1n-th3-m4rg1ns').digest()
print(AESGCM(key).decrypt(nonce, ct, None))
# b'GPI{th3_r0ws_r3m3mb3r_h0w_th3y_w3r3_wr1tt3n_3a7c}'
```

The GCM tag check passes, so the key and data are confirmed. The `candle-and-bell-1692` passphrase fails the same check.

## Flag

```
GPI{th3_r0ws_r3m3mb3r_h0w_th3y_w3r3_wr1tt3n_3a7c}
```

**Takeaway:** a PNG can hide data in its encoding as well as its pixels: chunk sizes, how the data is split across IDAT chunks, per-row filter choices and zlib settings. Re-saving the image in any editor destroys all of it, while the picture looks exactly the same.
