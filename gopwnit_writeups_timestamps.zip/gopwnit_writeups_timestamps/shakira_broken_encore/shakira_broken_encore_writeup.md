# SHAKIRA: The Broken Encore: writeup

**Category:** Reverse Engineering · **Difficulty:** Hard · **Points:** 150 · **Author:** BHAIYA_JI

**Flag:**

```
ENCORE{2372f289d37d29394982046737216602f8fd12f117c9af5ebe37dbcd43bc6a66d4fab5cd9ad24905e3ad427e2f896afde869}
```

Confirmed: the unmodified binary prints `ALL 5 REHEARSAL CUES SYNCHRONIZED!` (exit code 0), and that includes the final integrity-digest check over the whole flag.

## Files

| File | Role |
|---|---|
| `encore` | stripped PIE ELF checker: `./encore verify <flag>` |
| `choreography.dat` | `FOOT` file, the stage 1 target |
| `rhythm.bc` | `2YHR` bytecode for the custom VM in stage 2 |
| `rehearsal.vault` | 224 MB `VAULT_V1` archive, stages 3 and 5 |
| `liblighting.so` | loaded with `dlopen`, exports `lighting_evaluate_score`, stage 4 |

## Overall structure (main @ 0x12e0)

- `argc == 3`, `argv[1] == "verify"`, `strlen(flag) == 108`
- The flag starts with `ENCORE{` and ends with `}`. The middle is **5 fragments × 20 hex digits = 5 × 10 bytes**. On the stack: F1 @ `rsp+0x30`, F2 @ `+0x3a`, F3 @ `+0x44`, F4 @ `+0x4e`, F5 @ `+0x58`.

| Stage | Function | Input | Check |
|---|---|---|---|
| 1 CUE-FOOTWORK-01 | `0x1e20` → `0x1bf0` | F1, `choreography.dat` | transform(F1) == record 7 of the file; produces the VM seed `hash(F1) ^ 0x5348414b` |
| 2 CUE-RHYTHM-02 | `0x1fe0` (VM) | `rhythm.bc` + seed | VM output (10 bytes) == F2 |
| 3 CUE-VAULT-03 | `0x2650`, `0x2740` | vault, F2 | extracted chunk == F3 |
| 4 CUE-LIGHTS-04 | `liblighting.so!lighting_evaluate_score` | stage 3 state, F3 | score vector == F4 |
| 5 CUE-ENCORE-05 | `0x29f0` | vault, F1..F4 | authenticated record == F5 |
| final | `0x3530` | the whole flag | 32-byte digest == constant @ `0x5880` |

Each stage after the first works out the **expected** fragment itself, then compares it with `memcmp`. Stage 1 has to be inverted by hand. Stages 2–5 can be read straight out of memory.

## Stage 1: inverting the footwork cipher

`choreography.dat`: a 28-byte header (`FOOT`, `CUE-FOOTWORK-01`, record count ≥ 8), then 8 × 16-byte records. Record 7 has tag `0x0057` and target bytes `7bc8386f3a8f30eaaf8a`.

`fcn_1bf0(F1)` (tables taken from `.rodata`):

1. Pass each byte through the **AES S-box** (@ `0x58e0`)
2. **Permute** with `P = [4,7,1,9,0,8,3,5,2,6]` (@ `0x58b8`): `t[P[i]] = b[i]`
3. **4-round Feistel** on 5-byte halves, with round keys @ `0x58a0` (5 bytes per round):
   ```
   F0 = rol(R1,3) ^ (R0+k0)      F1 = ror(R2,3) ^ (R1+k1)
   F2 = rol(R3,2) ^ (R2+k2)      F3 = rol(R4,4) ^ (R3+k3)
   F4 = (R4+k4) ^ rol(R0,1)
   G  = Sbox[F];   L, R = R, L ^ G
   ```
   (The loop counter is hidden behind an opaque `((x+1)*x & 1) ^ x` dispatcher, but it always runs exactly 4 rounds.)

A Feistel network runs backwards using the same round function, so:

```python
def inv(out):
    L, R = list(out[:5]), list(out[5:])
    for r in reversed(range(4)):
        g = G(L, r); L, R = [R[i] ^ g[i] for i in range(5)], L
    t = L + R
    return bytes(SI[t[P[i]]] for i in range(10))   # undo the permutation, then the inverse S-box

inv(bytes.fromhex('7bc8386f3a8f30eaaf8a'))  # → 2372f289d37d29394982 (forward check ✔)
```

**F1 = `2372f289d37d29394982`**

## Stages 2–5: read the expected values at each memcmp

With F1 correct, run `encore` under plain gdb (`-nx`, to avoid pwndbg) with Python breakpoints on each `memcmp`. At each one, print the computed buffer (`rdi`) and copy it into the input slot (`rsi`) so later stages get the right input:

| memcmp @ | Fragment | Value |
|---|---|---|
| `0x1679` | F2 (rhythm VM) | `046737216602f8fd12f1` |
| `0x1701` | F3 (vault chunk) | `17c9af5ebe37dbcd43bc` |
| `0x178a` | F4 (lighting score) | `6a66d4fab5cd9ad24905` |
| `0x17e6` | F5 (encore record) | `e3ad427e2f896afde869` |

```python
import gdb
gdb.execute('set disable-randomization on'); gdb.execute('starti')
base = 0x555555554000; inf = gdb.selected_inferior()
class Bp(gdb.Breakpoint):
    def __init__(s, off, n): super().__init__('*%#x' % (base + off), internal=True); s.n = n
    def stop(s):
        rdi = int(gdb.parse_and_eval('$rdi')); rsi = int(gdb.parse_and_eval('$rsi'))
        v = bytes(inf.read_memory(rdi, 10)); print(s.n, v.hex()); inf.write_memory(rsi, v)
        return False
for off, n in ((0x1679, 'F2'), (0x1701, 'F3'), (0x178a, 'F4'), (0x17e6, 'F5')): Bp(off, n)
gdb.execute('continue')
```

```bash
gdb -nx -q -batch -x harvest.py --args ./encore verify "ENCORE{2372f289d37d29394982$(printf '0%.0s' {1..80})}"
```

(That run ends with "Integrity digest mismatch" only because the digest covers the original argv string, which still had zeros in it.)

## Verification

```
$ ./encore verify ENCORE{2372f289d37d29394982046737216602f8fd12f117c9af5ebe37dbcd43bc6a66d4fab5cd9ad24905e3ad427e2f896afde869}
[+] [CUE-FOOTWORK-01] Footwork sequence synchronized.
[+] [CUE-RHYTHM-02] Rhythm Machine VM synchronized.
[+] [CUE-VAULT-03] Rehearsal Vault chunk synchronized.
[+] [CUE-LIGHTS-04] Lighting Score matrix synchronized.
[+] [CUE-ENCORE-05] Master Encore sequence synchronized.
[+] ALL 5 REHEARSAL CUES SYNCHRONIZED!
[+] The Broken Encore has been fully restored.
```

## Flag

```
ENCORE{2372f289d37d29394982046737216602f8fd12f117c9af5ebe37dbcd43bc6a66d4fab5cd9ad24905e3ad427e2f896afde869}
```
