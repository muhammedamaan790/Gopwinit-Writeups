# SKILL ISSUE: writeup

**Category:** Miscellaneous (OSINT + Forensics) · **Difficulty:** Medium · **Points:** 100 · **Author:** BHAIYA_JI

**Flag:** `SKILL{faf6e03adfb6964dd375b9cca79b4ab6_REASONING_OVER_PROMPTS}`

Verified with the challenge site's own checker (`POST /api/submit-flag` → `"verdict":"AUTHENTIC_SOLVE"`).

## Challenge

Web app: https://skill-issue-ctf-blue.vercel.app. Evidence archive: `/api/evidence/download`.

The site is built to trap solvers who grab the first flag-shaped string. It plants canary seeds, revoked-key commits, a staging build and a Base64 "hint". The real flag comes from a 5-step chain using only **verified** artifacts.

## Evidence

```
manifest.json            PGP-signed release manifest (SHA-256 of dist/ artifacts)
gitforge_audit.json      commits + PGP signature status + advisory SEC-ADV-2026-004
syslog_telemetry.log     heur-srv-02 logs (canary daemon, chrony skew, build, failsafe)
chirpnet_export.json     @xero_entropy social feed (incl. edited post #407)
postmortem_draft.md      the derivation formula
staging/auth_guard.min.js   untrusted staging build (decoy)
dist/auth_guard.min.js      production build
dist/core_engine.wasm
```

## Decoys

| Decoy | Why it's rejected |
|---|---|
| Seed `V1B3_C0D1NG_D34TH_2026` and commit `7b32a0d84f` (ChirpNet #402, syslog PID 4091) | Commit signed with key `0xDEADBEEF99`, **revoked** by SEC-ADV-2026-004; authored by "Canary Daemon"; post flagged `is_canary_bait` |
| Base64 in post #405 → `SKILL{you_thought_base64_was_osint_lmao_skill_issue}` | flagged `is_decoy_base64` |
| `staging/auth_guard.min.js` → `sessionFailsafe:'VIBE_INSPECTION_MODE'`, key `0xDEADBEEF99` | SHA-256 `d5434d6b…` is not in `manifest.json`; the manifest says staging is untrusted |

## Step 1: Verified commit and signer

`gitforge_audit.json`: SEC-ADV-2026-004 revokes `0xDEADBEEF99`. All commits after 2026-01-01 must be signed by `0x4A89C2F150`.

The release containment commit, rebased onto `origin/hardened-core`, with a **VALID / ULTIMATE** signature from `0x4A89C2F150`:

- commit **`c48e89f2a6`**, signer **`xero_entropy@heuristi.core`**
- also confirmed in syslog: `Commit c48e89f2a6 verified successfully with PGP key 0x4A89C2F150`

```
KEY = SHA256("xero_entropy@heuristi.core:c48e89f2a6")
    = 6aacf8b00f6a525f8c1f88981f72db64b3843a99864bef15ddb014f546cec812
```

## Step 2: Salt from the verified production build

```bash
sha256sum dist/auth_guard.min.js
# f1d0505324d0168b7dab6a6d9d7a3fbaca448db84d3558fe15e00592b922c719
```

This matches `manifest.json` → `checksums["dist/auth_guard.min.js"]` and the build-d log line. Salt = first 16 hex characters = **`f1d0505324d0168b`** (rule from the *edited* ChirpNet post #407 and the postmortem).

## Step 3: Clock skew

heur-srv-02 ran 840 s (14 min) skewed until chrony stepped it at `2026-04-12T04:15:30Z`. With timestamps normalised, the causal order is: canary commit (04-11) → skew fixed (04-12) → salt rule edited (04-13) → real containment commit `c48e89f2a6` (04-14 19:04Z) → production build and manifest (19:08Z) → failsafe sealed (19:10Z). So the 04-14 commit is the final authoritative release.

## Step 4: Failsafe token

- Production `dist/auth_guard.min.js`: `sessionFailsafe:'REASONING_OVER_PROMPTS'`, signer constant `'0x4A89C2F150'`
- syslog `2026-04-14T19:10:00Z auth-guard[9115]: ... Session status code locked: REASONING_OVER_PROMPTS`
- commit `c48e89f2a6` message: `Lockdown status: REASONING_OVER_PROMPTS`

Token = **`REASONING_OVER_PROMPTS`**

## Step 5: PBKDF2

```python
import hashlib
key  = hashlib.sha256(b'xero_entropy@heuristi.core:c48e89f2a6').hexdigest()   # hex string, as UTF-8
salt = hashlib.sha256(open('dist/auth_guard.min.js', 'rb').read()).hexdigest()[:16]
dk   = hashlib.pbkdf2_hmac('sha256', key.encode(), salt.encode(), 10000, 16).hex()
print(f'SKILL{{{dk}_REASONING_OVER_PROMPTS}}')
# SKILL{faf6e03adfb6964dd375b9cca79b4ab6_REASONING_OVER_PROMPTS}
```

## Verification

```bash
curl -s -X POST https://skill-issue-ctf-blue.vercel.app/api/submit-flag \
  -H 'Content-Type: application/json' \
  -d '{"flag":"SKILL{faf6e03adfb6964dd375b9cca79b4ab6_REASONING_OVER_PROMPTS}"}'
# {"success":true,"verdict":"AUTHENTIC_SOLVE", ... "solver_level":"ELITE_INVESTIGATOR"}
```

## Flag

```
SKILL{faf6e03adfb6964dd375b9cca79b4ab6_REASONING_OVER_PROMPTS}
```
