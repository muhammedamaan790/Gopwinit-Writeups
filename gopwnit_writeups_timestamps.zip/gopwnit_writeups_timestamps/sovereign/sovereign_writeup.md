# Sovereign: Writeup

**Challenge:** Sovereign (gopwnit CTF 2026)
**Category:** OSINT / Digital Forensics
**Flag format:** `GPI{<antenna_code>_<target_island>_<incident_year>_<hex_auth>}`

---

## Files

| File | What it is |
|---|---|
| `incident_report.txt` | Defines the flag template. It says to recover the geolocation, the Q-ID entity link, and the "cryptographic citation parameter" from the revision diffs. |
| `wikipedia_history_dump.xml` | A MediaWiki export of the Bouvet Island article and a user talk page. |
| `survey_station_alpha.jpg` | A rendered "archival photometry" text card. |

---

## Step 1: Revision dump

The **Bouvet Island** page has two revisions:

- **rev 7419082** by `SovereignCartographer` at 14:18:32
- **rev 7419114**, where `Curps` reverts it at 14:21:05 as "Uncited Cold War military conspiracy theories"

The reverted revision is the payload. Its edit summary mentions a **"1979 incident"** and a **"Wullenweber monitoring station"**. The body has a hidden HTML comment (`TELEMETRY CIPHER INTEGRITY CHECK: PASS`) and a `{{cite journal}}` ref:

```text
id=Q31057:P625:WULLENWEBER
quote=Long-range High-Frequency Direction Finding (HFDF) station AN/FLR-9
      recorded signal convergence. Hexadecimal authorization crumb: 8f2c9a
```

- `Q31057` is the entity ID (Bouvet Island within the challenge).
- `P625` is Wikidata's "coordinate location" property.
- `WULLENWEBER` is the array type.
- `8f2c9a` is the hex auth.

The text also describes the **Vela satellite 6911** double flash of **September 1979** near Bouvet and Prince Edward Island.

The talk page warning (**rev 7419129**) repeats **AN/FLR-9** and **Bouvet Island**.

---

## Step 2: Image

The JPG is a text card that confirms every field:

```text
STATION: AN/FLR-9 [WULLENWEBER ARRAY]
CORRELATED TARGET: BOUVET ISLAND (54deg 25'S, 03deg 21'E)
SIGNAL EVENT: VELA ATMOSPHERIC FLASH (1979)
WIKIDATA IDENTIFIER Q31057
TELEMETRY HASH: 8f2c9a
```

The EXIF fields say the same thing:

```text
ImageDescription : Field survey of sub-Antarctic HFDF listening perimeter.
                   Target: Bouvet Island. Station: AN/FLR-9. Auth: 8f2c9a
Artist           : SovereignCartographer
UserComment      : STATION: AN/FLR-9 | TARGET: BOUVET | EVENT: 1979 | HASH: 8f2c9a
```

---

## Step 3: Map to flag fields

| Field | Value | Sources |
|---|---|---|
| `antenna_code` | `AN/FLR-9` → `an_flr_9` | cite quote, talk page, image |
| `target_island` | `bouvet` | page title, coordinates, image |
| `incident_year` | `1979` | Vela event, edit summary, image |
| `hex_auth` | `8f2c9a` | cite quote, image |

---

## Decoys

- **2004:** the edit date, not the incident year.
- **MD5 `a81f44d937c4e5e4125b04a8b71d8820`:** a file hash, not the 6-character auth crumb. It doesn't even match the shipped image.
- **Q31057:** fictional here. Bouvet Island's real Wikidata ID is Q23408, and Q31057 is actually Norfolk Island. Don't pivot to live Wikidata.
- **AN/FLR-9 location:** the real sites were all in the northern hemisphere, never the South Atlantic. The lore is planted, so trust the artifacts over reality.
- **Wikipedia identities:** the user `SovereignCartographer` doesn't exist, and the revision and user IDs don't match real enwiki records.
- **IP / Tor node, timestamps:** flavour text.

---

## Flag

The challenge required lowercase, and every separator in `AN/FLR-9` (both `/` and `-`) becomes `_`:

```text
GPI{an_flr_9_bouvet_1979_8f2c9a}
```
