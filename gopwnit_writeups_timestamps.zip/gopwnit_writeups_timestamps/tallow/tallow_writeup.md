# Tallow: writeup

**Category:** Cryptography · **Difficulty:** Easy · **Points:** 50 · **Author:** GOPWNIT

**Flag:** `GPI{sum_1s_n0t_x0r_4nd_th3_t00ls_kn0w_1t}` (matches the SHA-256 in `flag.sha256`)

## Challenge

> The rig draws one keystream per shift and seals every transmission of that shift under it; rotating mid-shift desynchronises the receiver, so they don't. Fourteen transmissions, 160 bytes each before sealing, one carries the dispatch seal. The sealing routine is included.

Attachment: `handout.zip` contains:
- `cipher.py`: the sealing routine
- `transmissions.txt`: 14 sealed messages in hex
- `flag.sha256`: the hash of the flag, for checking

## The cipher

```python
def seal(plaintext, keystream):
    return bytes((p + k) % 256 for p, k in zip(plaintext, keystream))

def pad(text):
    return text.ljust(160).encode()   # padded with spaces to 160 bytes
```

Every message is encrypted with **the same keystream**: a one-time pad used 14 times. The only twist is that the key is **added mod 256** instead of XORed. So the usual XOR tools (`xortool`, many-time-pad crib draggers) don't work directly, which is what the flag is hinting at.

The weakness is the same, though. In any single column `j`, all 14 messages use the same key byte `k[j]`. Trying all 256 values for `k[j]` and keeping the one that makes the column look most like English text recovers the key one column at a time.

The space padding helps: every message ends in a run of spaces, so the sealed rows share an identical tail. That tail is just the keystream shifted by `0x20`.

## Solver

```python
import sys, string

rows = [bytes.fromhex(l.split(':')[1].strip())
        for l in open('transmissions.txt') if l.startswith('tx-')]

# Rough English-like scoring of each byte
score = {c: 1 for c in range(256)}
score[ord(' ')] = 40
for c in b'etaoinshrdlu': score[c] = 12
for c in b'cmwfgypbvk':   score[c] = 6
for c in b'jxqz':         score[c] = 2
for c in string.ascii_uppercase.encode(): score[c] = 4
for c in b".,'-:;0123456789{}_": score[c] = 3
for c in range(256):
    if c < 32 or c > 126: score[c] = -100        # non-printable

key = [max(range(256), key=lambda k: sum(score[(r[j] - k) % 256] for r in rows))
       for j in range(160)]

for i, r in enumerate(rows):
    print(f'{i:02d}', bytes((c - k) % 256 for c, k in zip(r, key)).decode('latin1'))
```

## Output (key guessed column by column)

```
00 morning#shift opens the west fcoo} at six and the wax room staks locked ...
01 the dipsing frames were rebalaeceo last night so expect the seUond rack ...
...
04 the dissatch seal for this shi]t ts GPI{sum_1s_n0t_x0r_4nd_th3Qt00ls_kn0w_1t} and it is to be spoken to nobody ...
...
07 <random bytes>
...
```

- A few columns come out wrong because some letter positions are too rare in only 14 rows. Context fixes them: `dissatch` → `dispatch`, `th3Qt00ls` → `th3_t00ls`.
- **tx-07** decrypts to random bytes under this keystream. It's a decoy: either it was sealed under a different keystream or it's pure noise. Either way it holds nothing useful.
- **tx-04** carries the dispatch seal.

## Verify

```bash
printf '%s' 'GPI{sum_1s_n0t_x0r_4nd_th3_t00ls_kn0w_1t}' | sha256sum
# c1a937af84f067f0f62f06cff2191bab6184bfc6ec552e4383c05929a10fca8b  ← matches flag.sha256
```

## Flag

```
GPI{sum_1s_n0t_x0r_4nd_th3_t00ls_kn0w_1t}
```
