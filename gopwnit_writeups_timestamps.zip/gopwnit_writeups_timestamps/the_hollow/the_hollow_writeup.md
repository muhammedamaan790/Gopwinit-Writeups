# The Hollow — Writeup

**CTF:** GOPWNIT CTF 2026  **Category:** Cryptography  **Difficulty:** Hard  **Points:** 150

**Flag:** `GPI{0n3_f0ld_k3y_tw0_j0bs_4nd_4_sm00th_pr1m3}`

---

## Challenge

> Three envelopes off the batch-07 relay, which re-sent the batch twice; the nonce is the sequence number. One 128-bit fold key serves as both the MAC's evaluation point and the file-key seed — raised at review, recorded as acceptable. Behind the envelopes is a vault. notes.md is the full construction written out.

Handout files:

| File | Contents |
|---|---|
| `notes.md` | The full construction |
| `envelopes.txt` | Three `(nonce, ciphertext, tag)` triples |
| `stage2.bin` | Vault parameters, encrypted under a key derived from `H` |
| `flag.enc` | The flag, encrypted under a key derived from `H` and the vault exponent `x` |

## The construction

- **Encryption:** `keystream = sha256(H || nonce || ctr)` with a 4-byte big-endian counter, XORed with the plaintext.
- **Tag:** a GHASH-style polynomial MAC over GF(2^128), using GCM bit ordering, evaluated at `H`:

  ```
  acc = 0
  for each block B:  acc = (acc ⊕ B)·H
  acc = (acc ⊕ L)·H
  tag = acc ⊕ S,      S = sha256(H || nonce || "tag")[:16]
  ```

- `stage2.bin` is XORed with the counter keystream seeded by `sha256(H)`.
- `flag.enc` is XORed with the counter keystream seeded by `sha256(H_bytes || x_bytes)`.

There are two weaknesses to exploit:

1. **Nonce reuse.** The relay re-sent batch 07, so all three envelopes share the nonce `5468654e6f6e63655265757365` (`"TheNonceReuse"`).
2. **One key, two jobs.** Recovering the MAC key `H` also gives the file-encryption seed.

## Step 1: Recover H by exploiting the nonce reuse

Each ciphertext is exactly one 16-byte block, so `L` is the same for all three (128 bits). Because the nonce is the same, `S` is also the same. Each tag therefore has the form

```
tag_i = C_i·H² ⊕ L·H ⊕ S
```

XORing two tags cancels both `L·H` and `S`:

```
t0 ⊕ t1 = (C0 ⊕ C1)·H²   ⟹   H² = (t0 ⊕ t1) · (C0 ⊕ C1)^(-1)
```

Squaring is the Frobenius map in GF(2^128), so it is a bijection and every element has exactly one square root:

```
H = (H²)^(2^127)
```

Result:

```
H = d59d9939a0820f4dde7417d787839399
```

Checks:
- `(t0 ⊕ t2)/(C0 ⊕ C2)` gives the same `H²`.
- Recomputing all three full tags with `S = sha256(H || nonce || "tag")[:16]` reproduces them exactly.
- The envelopes decrypt to `release batch 07`, `hold batch 07!!!` and `amend batch 07 x`.

> The bit ordering matters. Per SP 800-38D, the MSB of byte 0 is the coefficient of x^0, so the reduction constant is `R = 0xE1 << 120` and you shift right.

## Step 2: Decrypt the vault parameters

`stage2.bin` XORed with the counter keystream seeded by `sha256(H)`:

```
# vault parameters, recovered from the stage-1 envelope
p = 0x8f96f1c50bca5b541b29cb07faff71cf91550ff66da9b29def479113b8db30374c58236d5c831c7dcce3225b8049d6a79f5bd777c378388e101559f5cedb3
g = 2
y = 0x6d77df6e0197809bc77d6a48062050b8b0e33e6e515e6dd443c5f6e99e7a3e282451398b8b6fc7f37078275709ad6426c663233b300512332984da4555473
```

## Step 3: Solve the discrete log with Pohlig–Hellman

`p` is a 500-bit prime. The notes say the generator chose `p` for a group order that is "easy to work with". Trial division followed by ECM factors `p − 1` as:

```
p − 1 = 2 · 2039 · 4049 · 9203 · 10847 · 12413 · 21521 · 28813 · 37549 · 39821
        · 43577 · 44687 · 48989 · 50651 · 50929 · 54091 · 57251
        · 136973113 · 754799435023 · Q
```

Here `Q` is a 200-bit prime. Everything except `Q` is smooth, with the largest factor about 2^40. The product of the smooth factors is `M = (p−1)/Q`, about 300 bits.

For each small prime `q`, solve `(g^((p−1)/q))^(x_q) = y^((p−1)/q)` with baby-step giant-step, then combine the results with CRT. This gives `x mod M`:

```
x = 227862127400457689541605767043391334023331758700378197292470935765364360301199523982608470   (297 bits)
```

`x` is "not small", but at 297 bits it is still smaller than `M`, so `x mod M` is the full exponent. The 200-bit prime `Q` never has to be dealt with. Decrypting the flag in the next step confirms that this is the right value.

## Step 4: Decrypt the flag

```
seed = sha256(H_bytes || x_bytes)      # x as minimal big-endian bytes
flag = flag.enc ⊕ counter_keystream(seed)
```

```
GPI{0n3_f0ld_k3y_tw0_j0bs_4nd_4_sm00th_pr1m3}
```

---

## Solver

The solver needs only `sympy`, which is used for CRT. Run it with the path to the handout directory.

```python
import sys, hashlib
from math import isqrt
from sympy.ntheory.modular import crt

D = sys.argv[1]
I = lambda b: int.from_bytes(b, 'big')
xor = lambda a, b: bytes(x ^ y for x, y in zip(a, b))

# --- GF(2^128), SP 800-38D bit order ---
R = 0xE1 << 120
def mul(x, y):
    z, v = 0, x
    for i in range(127, -1, -1):
        if (y >> i) & 1: z ^= v
        v = (v >> 1) ^ R if v & 1 else v >> 1
    return z
def pw(a, e):
    r = 1 << 127                      # the field's "1"
    while e:
        if e & 1: r = mul(r, a)
        a = mul(a, a); e >>= 1
    return r
inv = lambda a: pw(a, (1 << 128) - 2)

def ks(seed, n):
    o, i = b'', 0
    while len(o) < n:
        o += hashlib.sha256(seed + i.to_bytes(4, 'big')).digest(); i += 1
    return o[:n]

# --- Step 1: recover H from the reused nonce ---
envs, cur = [], {}
for line in open(D + '/envelopes.txt'):
    if '=' in line:
        k, v = [s.strip() for s in line.split('=')]
        cur[k] = bytes.fromhex(v)
        if k == 'tag': envs.append(cur); cur = {}
c = [I(e['ciphertext']) for e in envs]
t = [I(e['tag']) for e in envs]
H2 = mul(t[0] ^ t[1], inv(c[0] ^ c[1]))
H = pw(H2, 1 << 127)
assert mul(t[0] ^ t[2], inv(c[0] ^ c[2])) == H2
Hb = H.to_bytes(16, 'big')
print('H =', Hb.hex())

# --- Step 2: decrypt vault params ---
s2 = open(D + '/stage2.bin', 'rb').read()
txt = xor(s2, ks(hashlib.sha256(Hb).digest(), len(s2))).decode()
print(txt)
vals = {l.split('=')[0].strip(): int(l.split('=')[1], 0) for l in txt.splitlines() if '=' in l}
p, g, y = vals['p'], vals['g'], vals['y']

# --- Step 3: Pohlig-Hellman over the smooth part of p-1 ---
qs = [2, 2039, 4049, 9203, 10847, 12413, 21521, 28813, 37549, 39821, 43577,
      44687, 48989, 50651, 50929, 54091, 57251, 136973113, 754799435023]
def bsgs(a, b, q):
    m = isqrt(q) + 1; T = {}; e = 1
    for j in range(m): T.setdefault(e, j); e = e * a % p
    f = pow(a, -m, p); cc = b
    for i in range(m + 1):
        if cc in T: return i * m + T[cc]
        cc = cc * f % p
rs = [bsgs(pow(g, (p-1)//q, p), pow(y, (p-1)//q, p), q) for q in qs]
x = int(crt(qs, rs)[0])
print('x =', x)

# --- Step 4: decrypt flag ---
ct = bytes.fromhex(open(D + '/flag.enc').read().strip())
xb = x.to_bytes((x.bit_length() + 7) // 8, 'big')
print(xor(ct, ks(hashlib.sha256(Hb + xb).digest(), len(ct))).decode())
```

## Takeaways

- **Never reuse a nonce with a polynomial MAC.** With GHASH or a similar MAC, a single nonce reuse leaks the authentication key through simple field algebra. This is the "forbidden attack" on AES-GCM.
- **Keep keys separate.** Using the MAC key as the encryption seed turned a forgery problem into a full plaintext compromise.
- **Use safe primes for discrete-log groups.** If `p − 1` is mostly smooth, Pohlig–Hellman recovers any exponent that is shorter than the smooth part. A single large prime factor protects nothing if `x` fits under the smooth part.
