# Foldedlight — Cryptography Write-up

**Category:** Cryptography  
**Difficulty:** Medium  
**Points:** 100  
**Author:** gopwnit

## Challenge summary

The handout contains five encrypted archive members, a cleartext licence, the sealing implementation, and an RSA-encrypted dispatch:

```text
handout/
├── archive/
│   ├── member-00.bin
│   ├── member-01.bin
│   ├── member-02.bin
│   ├── member-03.bin
│   └── member-04.bin
├── dispatch.enc
├── licence.txt
├── manifest.md
└── sealer.py
```

The manifest provides two critical clues:

1. Member 00 is the archive licence, and its plaintext is supplied as `licence.txt`.
2. Member 03 contains damaged key material; nine bytes of that key material were replaced with zeroes.

## 1. Identifying the nonce-reuse vulnerability

The relevant part of `sealer.py` is:

```python
NONCE_MODULUS = 3

def seal(key: bytes, index: int, data: bytes) -> bytes:
    nonce = index % NONCE_MODULUS
    return bytes(
        a ^ b
        for a, b in zip(data, keystream(key, nonce, len(data)))
    )
```

Only three nonces are used regardless of the number of members:

| Member | Nonce |
|---:|---:|
| 00 | 0 |
| 01 | 1 |
| 02 | 2 |
| 03 | 0 |
| 04 | 1 |

Members 00 and 03 therefore use the same keystream.

For a stream cipher constructed with XOR:

```text
C00 = P00 XOR KS
C03 = P03 XOR KS
```

Because the plaintext of member 00 is known, its keystream can be recovered:

```text
KS = C00 XOR P00
P03 = C03 XOR KS
```

In Python:

```python
licence = open("handout/licence.txt", "rb").read()
member_00 = open("handout/archive/member-00.bin", "rb").read()
member_03 = open("handout/archive/member-03.bin", "rb").read()

keystream = bytes(a ^ b for a, b in zip(member_00, licence))
recovered = bytes(a ^ b for a, b in zip(member_03, keystream))
open("member-03.recovered.pem", "wb").write(recovered)
```

The result is a structurally valid PKCS#1 PEM file beginning with:

```text
-----BEGIN RSA PRIVATE KEY-----
...
-----END RSA PRIVATE KEY-----
```

## 2. Locating the damaged RSA fields

Parsing the recovered PEM as ASN.1 reveals the normal PKCS#1 sequence:

```text
version, n, e, d, p, q, dp, dq, qInv
```

The nine missing bytes appear in two fields:

- five consecutive zero bytes in the private exponent `d`;
- four consecutive zero bytes in the second prime `q`.

The modulus `n`, public exponent `e`, and first prime `p` remain intact. This is enough to reconstruct the key because:

```text
q = n // p
phi = (p - 1)(q - 1)
d = e^(-1) mod phi
```

It is unnecessary to brute-force any of the nine damaged bytes.

## 3. Reconstructing the key and decrypting the dispatch

`dispatch.enc` contains textbook RSA ciphertext as a hexadecimal big-endian integer, with no padding:

```text
c = m^e mod n
```

After reconstructing `q` and `d`, the plaintext is recovered with:

```text
m = c^d mod n
```

The following complete solver uses only Python's standard library. It also includes a minimal DER parser so the RSA values are extracted directly from the recovered PEM rather than copied manually.

```python
from base64 import b64decode
from pathlib import Path

ROOT = Path("handout")


def read_length(data: bytes, pos: int):
    first = data[pos]
    pos += 1
    if first < 0x80:
        return first, pos
    count = first & 0x7F
    length = int.from_bytes(data[pos:pos + count], "big")
    return length, pos + count


def read_tlv(data: bytes, pos: int):
    tag = data[pos]
    length, start = read_length(data, pos + 1)
    end = start + length
    return tag, data[start:end], end


# Recover member 03 via the keystream reused by member 00.
licence = (ROOT / "licence.txt").read_bytes()
c00 = (ROOT / "archive/member-00.bin").read_bytes()
c03 = (ROOT / "archive/member-03.bin").read_bytes()

keystream = bytes(a ^ b for a, b in zip(c00, licence))
pem = bytes(a ^ b for a, b in zip(c03, keystream))

# Decode the PKCS#1 PEM and extract its INTEGER fields.
lines = pem.decode().strip().splitlines()
der = b64decode("".join(lines[1:-1]))

tag, sequence, end = read_tlv(der, 0)
assert tag == 0x30 and end == len(der)

integers = []
pos = 0
while pos < len(sequence):
    tag, value, pos = read_tlv(sequence, pos)
    assert tag == 0x02
    integers.append(int.from_bytes(value, "big"))

version, n, e, damaged_d, p, damaged_q, dp, dq, q_inv = integers

# p is intact, so recover q and then calculate the true private exponent.
assert n % p == 0
q = n // p
phi = (p - 1) * (q - 1)
d = pow(e, -1, phi)

# Textbook RSA decryption.
c = int((ROOT / "dispatch.enc").read_text().strip(), 16)
m = pow(c, d, n)
flag = m.to_bytes((m.bit_length() + 7) // 8, "big")

# Verification: encrypting the result must reproduce the ciphertext.
assert pow(int.from_bytes(flag, "big"), e, n) == c
print(flag.decode())
```

Running it produces:

```text
GPI{th3_l1br4ry_r3fus3d_s0_1_p4rs3d_1t_mys3lf}
```

## Flag

```text
GPI{th3_l1br4ry_r3fus3d_s0_1_p4rs3d_1t_mys3lf}
```

## Vulnerabilities used

- Keystream reuse caused by reducing archive indices modulo three.
- A known-plaintext attack using the duplicated plaintext licence.
- RSA private-key reconstruction from the intact modulus and one surviving prime.
- Textbook RSA decryption without padding.
