# GoPwnIt OSINT — catch_me

## Objective

Identify the two genuine payloads among 50 buttons at <https://osint-seven-flax.vercel.app/>, submit them in order to the Flag Recombiner, and recover the `GPI{...}` flag.

## Artifacts

- [`original/index.html`](../original/index.html): page fetched from the supplied site.
- [`original/app.js`](../original/app.js): JavaScript containing all 50 button payloads and the offline cipher.
- [`original/reveal.json`](../original/reveal.json): response from the site's reveal endpoint for the winning pair.
- [`scripts/solve.py`](../scripts/solve.py): reproducible local search over the 50 payloads.

## Initial triage

The page says that 48 buttons are decoys and two contain Base64 parts. Its HTML loads `app.js`. In that file, `SECTORS` is a 50-element array; button `n` displays `SECTORS[n - 1]`. The same file defines a hex-encoded `CIPHER` and a fallback decryptor that XORs each cipher byte with a character from the **concatenated Base64 strings**. It tries both input orders and accepts a result beginning with `GPI{` and ending with `}`.

Base64-decoding button 17 produces the readable prefix `GPI{TH0NKYOU_D1R`. Button 37 decodes to binary-looking bytes, so readable Base64 output alone is insufficient to identify both genuine parts.

## Analysis and solution

I extracted the 50 strings and the cipher from the saved JavaScript. [`scripts/solve.py`](../scripts/solve.py) tests every ordered pair of different buttons (50 × 49 = 2,450 pairs), repeating the site's XOR operation. Only one pair produces a printable `GPI{...}` string:

| Order | Button | Base64 payload |
| --- | ---: | --- |
| Part 1 | 17 | `R1BJe1RIME5LWU9VX0QxUk` |
| Part 2 | 37 | `xJTkdfVDBfRjhJTkRfTTF9` |

The other 48 payloads do not form an accepted pair under that test. Most decode to nontext bytes; the decisive check is the cipher result, not appearance or Base64 padding.

The key is the literal string `part1 + part2`, without Base64-decoding it first. XORing the cipher against the repeating key yields:

```text
GPI{TH0NKYOU_D1RLING_T0_F8IND_M1}
```

## Commands used

```bash
curl -sS -o /tmp/gpi_index.html https://osint-seven-flax.vercel.app/
curl -sS -o /tmp/gpi_app.js https://osint-seven-flax.vercel.app/app.js
python3 scripts/solve.py
curl -sS -X POST https://osint-seven-flax.vercel.app/api/reveal \
  -H 'Content-Type: application/json' \
  --data '{"part1":"R1BJe1RIME5LWU9VX0QxUk","part2":"xJTkdfVDBfRjhJTkRfTTF9"}'
```

The script prints buttons 17 and 37 and the flag above. The live `/api/reveal` endpoint returned:

```json
{"success":true,"flag":"GPI{TH0NKYOU_D1RLING_T0_F8IND_M1}"}
```

This confirms the site's recombiner accepts those exact parts in that order. No unresolved steps remain.

## Verified flag

```text
GPI{TH0NKYOU_D1RLING_T0_F8IND_M1}
```
