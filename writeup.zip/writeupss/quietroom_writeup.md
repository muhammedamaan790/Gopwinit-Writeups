# Quietroom — CTF Writeup

## Challenge Information

- Challenge: Quietroom
- Category: Cryptography
- Difficulty: Medium
- Flag format: `GPI{...}`

## Challenge Description

The attachment contains 256 truncated timing traces of a left-to-right modular exponentiation. Every exponent bit causes a square; set bits also cause a multiply. The operations are aligned across captures, but each sample has jitter and occasional large, one-sided contention spikes. The public value `y = g^x mod p` lets us verify a recovered exponent.

## Solution

For each operation index, take the median across all traces that contain that index. The traces are prefixes of the same sequence, so samples at a given index refer to the same operation. The median suppresses the positive contention spikes. The two timing bands are distinct: square medians are around `1.01`, while multiply medians are around `1.09`. A threshold of `1.05` separates them.

The longest common prefix contains 216 operations. Parse it by consuming one square per bit, then consuming a multiply if the next operation is classified as one. This recovers 144 exponent bits. The remaining 16 bits are feasible to enumerate; for each suffix, check whether the resulting exponent satisfies `pow(g, x, p) == y`. Exactly one suffix matches.

The solver then derives the 32-byte key as `SHA-256(x.to_bytes(20, "big"))` and XORs it with the ciphertext, repeating the digest as needed.

## Reproduction

```bash
python3 solve.py
```

The script uses only Python's standard library and reads `original/1791624163356-handout.zip` directly.

## Key Evidence

- Trace count: 256.
- Shortest trace: 216 operations; longest: 228.
- Median timing classes: squares near `1.01`, multiplies near `1.09`.
- Recovered prefix: 144 bits, including 72 set bits.
- Enumerated suffix: 16 bits; exactly one candidate matches the published `y`.
- Recovered exponent: `936490666195134173660827259253011776665639626904`.
- Verification: `pow(5, x, p) == y` evaluates to true.

## Verified Flag

```text
GPI{th3_m3d14n_h34rs_wh4t_th3_m34n_c4nn0t}
```

## Lessons / Observations

Repeated aligned measurements can expose a small timing difference even when individual samples overlap. A median is robust to this capture's one-sided outliers, and the published public result provides a strong check for the recovered secret.
