# We Are Sorry Folks — CTF Write-up

| Field | Details |
|---|---|
| **CTF** | Gopwnit CTF 2026 |
| **Author** | aadityagoyal |
| **Category** | Other |
| **Difficulty** | Hard |
| **Points** | 150 |
| **Tags** | apology, sorry |

## Final Flag

    GPI{why_4re_y0u_u5ing_c1AUd3_f0r_s01ving_CTF}

## TL;DR

The challenge link leads to a Google Form that always “apologizes” after submission.

The real target is a Vercel page disguised as an “Under Maintenance” wall. Its entire HTML is hidden inside a Base64-encoded document.write() call.

Decoding the page reveals a hidden client-side routine:

1. Click the footer 15 times within a two-second window.
2. Concatenate three secret strings hidden in the DOM and CSS.
3. Base64-decode the result.
4. Reverse the decoded bytes.
5. XOR the bytes with a five-byte key.

The result is the flag.

## Description Analysis

The challenge description says:

> Sometimes, the door doesn't open with the first knock, but with the one you almost gave up on. And sometimes, the answer reveals itself only when time has heard you ask enough times.

This contains two hints.

### “The knock you almost gave up on”

Persistence is required. Expect a wall of failures before something yields.

### “When time has heard you ask enough times”

This suggests a counting mechanism tied to time. It is not a rate-limit bypass; it is an interaction that must be repeated a certain number of times within a time window.

The tags apology and sorry point toward a service that repeatedly says “sorry.” This behavior is a decoy that must be investigated rather than trusted.

## Step 1 — The Google Form Decoy

The challenge’s “Click here” link leads to a Google Form.

No matter what is submitted, the confirmation page responds:

    We are sorry folks!! We still want you to explore, just like your ex did.
    The given link may be incorrect, I am not sure.
    Admin Loves You All.

This is the first “sorry” wall. The form itself does not provide the flag.

However, the line:

    The given link may be incorrect

suggests that the form description contains the real target:

    https://hell0-u3er.vercel.app/

The hostname hell0-u3er is “hello user” written in leetspeak.

## Step 2 — Recon on the Vercel Page

A plain GET request returns a tiny HTML document consisting of one line:

    <script>
        document.write(
            decodeURIComponent(
                escape(
                    atob("PCFET0NUWVBFIGh0bWw+...")
                )
            )
        );
    </script>

The entire page is Base64-encoded and written to the DOM at runtime.

Therefore:

- The raw HTTP response is not the real page.
- A normal curl response appears to contain only an encoded payload.
- The rendered DOM and the source response are completely different.
- The Base64 payload must be extracted and decoded.

### Decoding the Payload

The payload can be extracted and decoded with:

    curl -s https://hell0-u3er.vercel.app/ \
      | sed -E 's/.*atob\("(.*)"\).*/\1/' \
      | base64 -d

This yields the real page:

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <title>Under Maintenance</title>

        <style>
            :root {
                --a: "Ln5Pdw8JEB9MPSZISWYF"
                <!-- piece #2: hidden in CSS -->
            }
        </style>
    </head>

    <body data-k="PREFTD86FSNqMj9aNUMd">
        <!-- piece #3: hidden on <body> -->

        <main>
            <h1>Under Maintenance</h1>
            <p>
                Wrong destination Folks!!
                Try searching on the <b>leaderboard</b>.
            </p>
            <div id="out"></div>
        </main>

        <footer>
            &copy;
            <span id="y" data-z="NWcoUAUvTxVla3hSI2Fq">
                2026
            </span>
            Gopwnit CTF 2026
        </footer>

        <script>
            (function () {
                var c = 0, t;
                var K = [90, 19, 124, 33, 72];

                document.getElementById('y')
                    .addEventListener('click', function () {
                        c++;

                        clearTimeout(t);

                        t = setTimeout(function () {
                            c = 0;
                        }, 2000);

                        if (c < 15) return;

                        c = 0;

                        var s =
                            this.dataset.z
                            + getComputedStyle(
                                document.documentElement
                              )
                                .getPropertyValue('--a')
                                .replace(/"/g, '')
                                .trim()
                            + document.body.dataset.k;

                        var d = atob(s);
                        var r = [];

                        for (var i = 0; i < d.length; i++) {
                            r.push(d.charCodeAt(i));
                        }

                        r.reverse();

                        document.getElementById('out')
                            .textContent =
                            r.map(function (v, i) {
                                return String.fromCharCode(
                                    v ^ K[i % 5]
                                );
                            })
                            .join('');
                    });
            })();
        </script>
    </body>
    </html>

## Step 3 — Understanding the Mechanism

The footer copyright text is the “door” from the description.

The relevant event handler works as follows:

1. Each click increments the counter c.
2. A timer is reset after every click.
3. If two seconds pass without another click, the counter resets to zero.
4. When c reaches 15, the decryption routine runs.
5. The counter is then reset to zero.

Therefore, the solution requires 15 clicks, with every click occurring within two seconds of the previous one.

### Hidden Data Pieces

The routine combines three strings hidden in different layers:

| Source | Value |
|---|---|
| Footer span data-z | NWcoUAUvTxVla3hSI2Fq |
| CSS custom property --a | Ln5Pdw8JEB9MPSZISWYF |
| Body data-k | PREFTD86FSNqMj9aNUMd |

The concatenated string is:

    s = data-z + --a + data-k

The decryption process is:

    d        = Base64Decode(s)
    r        = bytes(d) reversed
    flag[i]  = chr(r[i] XOR K[i % 5])

The XOR key is:

    K = [90, 19, 124, 33, 72]

## Step 4 — Solving the Challenge

### Intended Method: Use the Browser

Open the site and click the footer copyright text 15 times quickly.

Each click must occur within two seconds of the previous click, so rapidly clicking or spam-clicking works.

Once the counter reaches 15, the flag appears in the page as green monospace text inside the output element.

### Offline Method: Reproduce the Decryption

The same process can be reproduced in Python without using a browser:

    #!/usr/bin/env python3

    import base64

    DATA_Z = "NWcoUAUvTxVla3hSI2Fq"
    CSS_A = "Ln5Pdw8JEB9MPSZISWYF"
    DATA_K = "PREFTD86FSNqMj9aNUMd"

    K = [90, 19, 124, 33, 72]

    s = DATA_Z + CSS_A + DATA_K

    d = base64.b64decode(s)

    r = list(d)
    r.reverse()

    print(
        "".join(
            chr(v ^ K[i % 5])
            for i, v in enumerate(r)
        )
    )

The output is:

    GPI{why_4re_y0u_u5ing_c1AUd3_f0r_s01ving_CTF}

## Flag

    GPI{why_4re_y0u_u5ing_c1AUd3_f0r_s01ving_CTF}

The flag reads:

    "why are you using claude for solving CTF"

It is the administrator’s personal greeting to everyone who automated the challenge.

## Takeaways

- document.write(atob(...)) is a classic hiding trick. The raw HTTP response and the rendered DOM can be completely different.
- Always decode the payload instead of trusting view-source.
- Secrets split across multiple layers can survive casual inspection. In this challenge, the three pieces were distributed across an HTML attribute, a CSS custom property, and a body attribute.
- DevTools’ Elements view, the CSS panel, and view-source each reveal only part of the complete secret.
- Client-side gates such as click counters and timers are flavor, not security. The unlock logic runs in the browser and can be read and replayed offline.
- The description accurately maps the solution: persistence plus a time-bound counter equals 15 clicks within a two-second window.
