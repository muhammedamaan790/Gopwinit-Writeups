# VMProtect Password Recovery

**Category:** Reverse Engineering  
**Platform:** Linux with Wine  
**Flag:** `GPI{patrobicha}`

## Challenge summary

The target was a 64-bit C++ binary protected with VMProtect 3. It ran under Wine and used several environment checks and anti-debugging tricks before reaching its password prompt. The program did not print the complete flag; the password recovered from its runtime was `patrobicha`, so the expected submission was reconstructed as `GPI{patrobicha}`.

## Solution

### 1. Bypass the hypervisor check

The program checked CPUID leaf 1 for the hypervisor-present bit (ECX bit 31). I wrote a small `ptrace`-based shim, `cpuidhide.c`, to clear that bit from the result. The check expected a single-step trap after the CPUID instruction, so the shim emulated the expected instruction flow with a real two-byte NOP.

### 2. Handle the missing Wine API

Wine did not implement `RtlQueryProcessHeapInformation`, which the binary relied on during startup. Rather than patching the executable, I set a hardware breakpoint on the API address with `PTRACE_POKEUSER` and supplied a plausible return value in memory when execution reached it.

Using a hardware breakpoint kept the executable and system DLL bytes unchanged. That mattered because another thread compared the on-disk and in-memory copies of `ntdll.dll` and `kernel32.dll`, terminating the process if it detected a modification.

### 3. Prevent the Wine console hang

The program called `system("cls")`, which hung under Wine when standard input and output were piped. I pointed `COMSPEC` at `hostname.exe`, making the console-clear command a harmless no-op and allowing the process to continue.

### 4. Recover the password at runtime

With the checks bypassed, I traced the process through Wine's API relay and watched the memory operations around the password prompt. The binary copied the decrypted string `patrobicha` into memory immediately before prompting. It did not print that string as a standalone value, so observing the runtime copy revealed the credential directly.

### 5. Verify the result

I entered `patrobicha` at the prompt. The program printed:

```text
wtf how did you crack this
```

An incorrect password produced no such response, confirming that the recovered string was accepted.

## Flag

```text
GPI{patrobicha}
```

## Notes

The flag wrapper is reconstructed from the expected submission format. The binary exposed `patrobicha` as the password, but never printed the full `GPI{...}` string literally.
